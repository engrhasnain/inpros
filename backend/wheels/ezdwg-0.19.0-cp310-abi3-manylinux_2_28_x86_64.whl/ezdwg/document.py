from __future__ import annotations

import fnmatch
import math
import re
from functools import lru_cache, cached_property
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Iterable, Iterator, Mapping

from . import raw
from .entity import Entity
from .layer_states import LayerStateTable, build_layer_state_table
from .layer_filters import LayerFilterTable, LayerFilterTree, build_layer_filter_table, build_layer_filter_tree
from .layers import LayerTable, build_layer_table

if TYPE_CHECKING:
    from .drawing import Drawing
    from .graph import DocumentGraph

SUPPORTED_VERSIONS = {"AC1012", "AC1014", "AC1015", "AC1018", "AC1021", "AC1024", "AC1027", "AC1032"}
SUPPORTED_ENTITY_TYPES = (
    "LINE",
    "LWPOLYLINE",
    "POLYLINE_2D",
    "VERTEX_2D",
    "POLYLINE_3D",
    "VERTEX_3D",
    "POLYLINE_MESH",
    "VERTEX_MESH",
    "POLYLINE_PFACE",
    "VERTEX_PFACE",
    "VERTEX_PFACE_FACE",
    "SEQEND",
    "3DFACE",
    "SOLID",
    "TRACE",
    "SHAPE",
    "3DSOLID",
    "BODY",
    "VIEWPORT",
    "OLEFRAME",
    "OLE2FRAME",
    "LONG_TRANSACTION",
    "REGION",
    "RAY",
    "XLINE",
    "ARC",
    "CIRCLE",
    "ELLIPSE",
    "SPLINE",
    "POINT",
    "TEXT",
    "ATTRIB",
    "ATTDEF",
    "MTEXT",
    "LEADER",
    "HATCH",
    "IMAGE",
    "TOLERANCE",
    "MLINE",
    "BLOCK",
    "ENDBLK",
    "INSERT",
    "MINSERT",
    "DIMENSION",
)

TYPE_ALIASES = {
    "DIM_LINEAR": "DIMENSION",
    "DIM_RADIUS": "DIMENSION",
    "DIM_DIAMETER": "DIMENSION",
    "DIM_ORDINATE": "DIMENSION",
    "DIM_ALIGNED": "DIMENSION",
    "DIM_ANG3PT": "DIMENSION",
    "DIM_ANG2LN": "DIMENSION",
}

_BULK_PRIMITIVE_TYPES = {"LINE", "ARC", "CIRCLE"}
_EXPLICIT_ONLY_ENTITY_TYPES = {
    "BLOCK",
    "ENDBLK",
    "SEQEND",
    "VERTEX_2D",
    "VERTEX_3D",
    "VERTEX_MESH",
    "VERTEX_PFACE",
    "VERTEX_PFACE_FACE",
}
_POLYLINE_2D_INTERPOLATION_SEGMENTS = 8
_POLYLINE_2D_SPLINE_CURVE_TYPES = {"QuadraticBSpline", "CubicBSpline", "Bezier"}
_ACIS_ROLE_HINTS = {
    0x214: "acis-link-table",
    0x221: "acis-header",
    0x222: "acis-payload-chunk",
    0x223: "acis-payload-chunk",
    0x224: "acis-payload-chunk",
    0x225: "acis-payload-chunk",
}


@dataclass(frozen=True)
class _SimpleEntitySpec:
    """Declarative spec for simple entity iteration in ``Layout._iter_type``.

    - ``rows_fn(decode_path)`` returns an iterable of raw rows.
    - ``build_dxf(row, ctx)`` returns ``(handle, dxf_dict)`` or ``None`` to skip.
    - ``setup(decode_path)`` optionally computes a context object (e.g. an owner
      map) that is passed to ``build_dxf`` for every row. Called once per
      ``_iter_type`` dispatch.
    """

    rows_fn: Callable[[str], Iterable[Any]]
    build_dxf: Callable[[Any, Any], tuple[int, dict] | None]
    setup: Callable[[str], Any] | None = None


# $INSUNITS drawing-units codes (DXF reference).
INSUNITS_NAMES = {
    0: "unitless",
    1: "inches",
    2: "feet",
    3: "miles",
    4: "millimeters",
    5: "centimeters",
    6: "meters",
    7: "kilometers",
    8: "microinches",
    9: "mils",
    10: "yards",
    11: "angstroms",
    12: "nanometers",
    13: "microns",
    14: "decimeters",
    15: "decameters",
    16: "hectometers",
    17: "gigameters",
    18: "astronomical_units",
    19: "light_years",
    20: "parsecs",
    21: "us_survey_feet",
}

_HEADER_VARIABLE_KEYS = (
    "insunits",
    "lunits",
    "luprec",
    "aunits",
    "auprec",
    "ltscale",
    "textsize",
    "extmin",
    "extmax",
    "limmin",
    "limmax",
)


def read(path: str, lineweight_table: Mapping[int, int] | None = None) -> "Document":
    version = raw.detect_version(path)
    if version not in SUPPORTED_VERSIONS:
        raise ValueError(f"unsupported DWG version: {version}")
    return Document(path=path, version=version, lineweight_table=lineweight_table)


def clear_decode_caches() -> None:
    """Release module-level decode caches retained for previously read files.

    ``ezdwg`` caches decoded DWG tables and entity metadata because many
    ``Document`` methods reuse the same native decoder results. Long-running
    batch converters can call this after finishing a document so those cached
    collections do not keep the complete source model alive.

    Clears both:
      - pure-Python ``@lru_cache`` helpers defined in this module (legacy;
        do not add new ones -- prefer the shared Rust path-keyed cache in
        ``bindings/cache.rs``), and
      - the native decode cache exposed as ``raw.clear_decode_cache``
        (LAYER table FIFO today; future tables share the same entry point).
    """
    try:
        raw.clear_decode_cache()
    except Exception:
        pass
    seen: set[int] = set()
    for value in tuple(globals().values()):
        cache_clear = getattr(value, "cache_clear", None)
        value_id = id(value)
        if callable(cache_clear) and value_id not in seen:
            cache_clear()
            seen.add(value_id)


@dataclass(frozen=True)
class Document:
    path: str
    version: str
    decode_path: str | None = None
    decode_version: str | None = None
    lineweight_table: Mapping[int, int] | None = None

    def __post_init__(self) -> None:
        if self.decode_path is None:
            object.__setattr__(self, "decode_path", self.path)
        if self.decode_version is None:
            object.__setattr__(self, "decode_version", self.version)

    def edit(self, *, strict: bool = True, version: str = "AC1015") -> "Drawing":
        """Copy supported model-space and block data into an editable drawing.

        Losses reject the copy by default. ``strict=False`` retains diagnostics
        on the drawing, which also make a later strict save fail.
        """
        from .drawing import Drawing

        return Drawing.from_document(self, strict=strict, version=version)

    def modelspace(self) -> "Layout":
        """Entities that live in model space.

        Membership comes from each entity's common header (``entmode``) and stored
        owner handle: block-definition contents and paper-space entities are
        excluded. Entities whose placement cannot be read stay included so nothing
        is silently hidden.
        """
        return Layout(self, "MODELSPACE")

    def paperspace(self) -> "Layout":
        """Entities that live in paper space (any layout)."""
        return Layout(self, "PAPERSPACE")

    def entities(self) -> "Layout":
        """Every entity in the file: model space, paper space and block definitions.

        Use ``Entity.dxf["owner_handle"]`` / ``Document.entity_placement()`` to
        partition them (this is what ``ezdwg`` consumers that rebuild block
        definitions themselves need).
        """
        return Layout(self, "ENTITIES")

    def entity_placement(self, handle: int) -> tuple[int, int | None] | None:
        """``(entmode, owner_handle)`` of an entity, or ``None`` when unknown.

        ``entmode``: 0 = an owner handle is stored (block record or layout block),
        1 = paper space, 2 = model space, 3 = other.
        """
        placement = _entity_placement_map(self.decode_path).get(int(handle))
        if placement is None:
            return None
        mode, owner = placement
        return mode, (owner or None)

    def plot(self, *args, **kwargs):
        from .render import plot

        return plot(self, *args, **kwargs)

    def export_dxf(self, output_path: str, **kwargs):
        from .convert import to_dxf

        return to_dxf(self, output_path, **kwargs)

    def export_dwg(self, output_path: str, **kwargs):
        from .convert import to_dwg

        return to_dwg(self, output_path, **kwargs)

    @property
    def raw(self):
        return raw

    @cached_property
    def layers(self) -> LayerTable:
        return build_layer_table(self.decode_path or self.path, self.lineweight_table)

    @cached_property
    def layer_states(self) -> LayerStateTable:
        """Named layer states (ACAD_LAYERSTATES), immutable snapshot."""
        return build_layer_state_table(self.decode_path or self.path)

    @cached_property
    def viewport_overrides(self):
        """Live VP Freeze + LAYER xdict property overrides (mutable in memory).

        Mutated by ``LayerState.apply(..., viewport=…)``; never written back
        to the DWG or consumed by entity plotting/export.
        """
        from .layer_states import build_viewport_override_table

        return build_viewport_override_table(self.decode_path or self.path)

    @cached_property
    def layer_filters(self) -> LayerFilterTable:
        """Named property layer filters (ACAD_LAYERFILTERS), immutable snapshot."""
        return build_layer_filter_table(self.decode_path or self.path)

    @cached_property
    def layer_filter_tree(self) -> LayerFilterTree:
        """Nested AcLy layer filters (ACLYDICTIONARY), immutable snapshot."""
        return build_layer_filter_tree(self.decode_path or self.path)

    def layer_filter(self, name: str):
        """Return one property layer filter by name, or ``None``."""
        return self.layer_filters.get(name)

    def layer_state(self, name: str):
        """Return one layer state by name, or ``None``."""
        return self.layer_states.get(name)

    def diff_layer_state(self, name: str, **kwargs):
        """Compare a named layer state to this document's live layers.

        Keyword arguments are forwarded to ``LayerState.diff``.
        Raises ``KeyError`` if the state name is missing.
        """
        st = self.layer_states.get(name)
        if st is None:
            raise KeyError(name)
        return st.diff(self, **kwargs)

    def apply_layer_state(self, name: str, **kwargs):
        """Apply a named layer state to this document's layers (in memory).

        Keyword arguments are forwarded to ``LayerState.apply``.
        Raises ``KeyError`` if the state name is missing.
        Does not write DWG bytes.
        """
        st = self.layer_states.get(name)
        if st is None:
            raise KeyError(name)
        return st.apply(self, **kwargs)

    def graph(self, limit: int | None = None) -> "DocumentGraph":
        from .graph import read_graph

        return read_graph(self.decode_path or self.path, limit=limit)

    def header_variables(self) -> dict[str, Any]:
        """Decode the header-variables subset ($INSUNITS, unit formats, extents).

        Keys: ``insunits``, ``lunits``, ``luprec``, ``aunits``, ``auprec``,
        ``ltscale``, ``textsize``, ``extmin``, ``extmax``, ``limmin``,
        ``limmax``. Values are ``None`` when the variable is absent for the
        file version (R14 has no ``$INSUNITS``).
        """
        row = raw.decode_header_variables(self.decode_path or self.path)
        return dict(zip(_HEADER_VARIABLE_KEYS, row))

    def linetypes(self) -> dict[str, dict[str, Any]]:
        """Linetype table by name.

        Each entry holds ``handle``, ``description``, ``pattern_length`` and
        ``dashes``: the dash pattern in drawing units at linetype scale 1, with
        the DXF sign convention (positive = dash, negative = gap, 0 = dot).
        The table includes the built-in ``ByBlock``, ``ByLayer`` and
        ``Continuous`` entries, whose pattern is empty.
        """
        table: dict[str, dict[str, Any]] = {}
        for handle, name, description, pattern_length, dashes in _linetype_rows(
            self.decode_path or self.path
        ):
            table.setdefault(
                name,
                {
                    "handle": handle,
                    "description": description,
                    "pattern_length": pattern_length,
                    "dashes": list(dashes),
                },
            )
        return table

    def dimstyles(self) -> dict[str, dict[str, Any]]:
        """Dimension style table by name.

        Each entry holds ``handle``, ``dimscale`` (the overall scale; 0 for a
        style that is scaled by the viewport or annotatively), ``dimtxt`` (text
        height) and ``dimasz`` (arrow size). The sizes are in drawing units
        before ``dimscale``.
        """
        path = self.decode_path or self.path
        table: dict[str, dict[str, Any]] = {}
        for handle, entry in _dimstyle_map(path).items():
            table.setdefault(entry["name"] or f"DIMSTYLE_{handle:X}", {"handle": handle, **entry})
        for entry in table.values():
            entry.pop("name")
        return table

    def layouts(self) -> dict[str, dict[str, Any]]:
        """Layout table by name: the model tab and the paper-space sheets.

        Each entry holds ``handle``, ``tab_order`` (0 for the model tab),
        ``model`` (``True`` for the model tab), ``block_record_handle`` (the
        block record that owns the entities of the layout) and ``active``:
        ``True`` for the paper-space layout that was current when the file was
        saved. Its entities are the ones stored with ``entmode == 1`` and no
        owner handle (see ``entity_placement``); the entities of every other
        sheet name their block record as owner.

        The sheet itself is described by ``paper_width`` and ``paper_height``
        (millimetres, before ``plot_rotation``), ``margins`` (left, bottom,
        right, top; millimetres), ``paper_size`` (the name of the size),
        ``paper_units`` (0 inches, 1 millimetres, 2 pixels), ``plot_rotation``
        (0-3 quarter turns counter-clockwise), ``limmin`` / ``limmax`` and
        ``extmin`` / ``extmax`` in layout units, and ``viewport_handles``: the
        viewports of the layout with the sheet's own viewport first (R2004+;
        empty before).

        Files written before R2000 may hold no layout objects; the table is
        empty then.
        """
        path = self.decode_path or self.path
        table: dict[str, dict[str, Any]] = {}
        for handle, entry in sorted(
            _layout_map(path).items(), key=lambda item: (item[1]["tab_order"], item[0])
        ):
            table.setdefault(entry["name"] or f"LAYOUT_{handle:X}", {"handle": handle, **entry})
        for entry in table.values():
            entry.pop("name")
        return table

    @property
    def insunits(self) -> int | None:
        """Raw ``$INSUNITS`` drawing-units code, or ``None`` when unavailable."""
        try:
            return self.header_variables()["insunits"]
        except Exception:
            return None

    @property
    def units(self) -> str | None:
        """Drawing units name resolved from ``$INSUNITS`` (e.g. ``"millimeters"``).

        Returns ``None`` when the code is unavailable (R14, or an unreadable
        header). Unknown codes are reported as ``"unknown_<code>"``.
        """
        code = self.insunits
        if code is None:
            return None
        return INSUNITS_NAMES.get(code, f"unknown_{code}")


@dataclass(frozen=True)
class Layout:
    doc: Document
    name: str

    def iter_entities(
        self,
        types: str | Iterable[str] | None = None,
        *,
        include_styles: bool = True,
    ) -> Iterator[Entity]:
        return self.query(types, include_styles=include_styles)

    def query(
        self,
        types: str | Iterable[str] | None = None,
        *,
        include_styles: bool = True,
    ) -> Iterator[Entity]:
        type_set = _normalize_types(types, self.doc.decode_path)
        bulk_rows = None
        if sum(1 for dxftype in type_set if dxftype in _BULK_PRIMITIVE_TYPES) >= 2:
            bulk_rows = _line_arc_circle_rows(self.doc.decode_path)
        insert_minsert_rows = None
        dimension_rows = None
        if "INSERT" in type_set and "MINSERT" in type_set:
            decode_combined = getattr(raw, "decode_insert_minsert_dimension_entities", None)
            if "DIMENSION" in type_set and callable(decode_combined):
                try:
                    insert_rows, minsert_rows, dim_rows = decode_combined(self.doc.decode_path)
                    insert_minsert_rows = (list(insert_rows), list(minsert_rows))
                    dimension_rows = list(dim_rows)
                except Exception:
                    insert_minsert_rows = _insert_minsert_rows(self.doc.decode_path)
            else:
                insert_minsert_rows = _insert_minsert_rows(self.doc.decode_path)
        if include_styles:
            entity_style_map = _entity_style_map(self.doc.decode_path)
            layer_color_map = _layer_color_map(self.doc.decode_path)
            layer_color_overrides = _layer_color_overrides(
                self.doc.decode_version,
                entity_style_map,
                layer_color_map,
            )
        else:
            entity_style_map = {}
            layer_color_map = {}
            layer_color_overrides = None
        accepts = self._placement_filter()
        for dxftype in type_set:
            entities = self._iter_type(
                dxftype,
                bulk_rows=bulk_rows,
                insert_minsert_rows=insert_minsert_rows,
                include_styles=include_styles,
                entity_style_map=entity_style_map,
                layer_color_map=layer_color_map,
                layer_color_overrides=layer_color_overrides,
                dimension_rows=dimension_rows,
            )
            if accepts is None:
                yield from entities
                continue
            for entity in entities:
                if accepts(entity.handle):
                    yield entity

    def _placement_filter(self) -> Callable[[int], bool] | None:
        """Return the membership predicate for this layout (None = accept all)."""
        space = self.name.upper()
        if space not in {"MODELSPACE", "PAPERSPACE"}:
            return None
        placements = _entity_placement_map(self.doc.decode_path)
        if not placements:
            return None
        header_names = _block_header_name_map(self.doc.decode_path)
        modelspace_owners = {
            handle
            for handle, name in header_names.items()
            if name.strip().upper() in _MODELSPACE_BLOCK_NAMES
        }
        paperspace_owners = {
            handle
            for handle, name in header_names.items()
            if name.strip().upper().startswith("*PAPER_SPACE")
        }
        want_model = space == "MODELSPACE"

        def accepts(handle: int) -> bool:
            seen = set()
            while int(handle) not in seen:
                seen.add(int(handle))
                placement = placements.get(int(handle))
                if placement is None:
                    return want_model
                mode, owner = placement
                if mode == 2:
                    return want_model
                if mode == 1:
                    return not want_model
                if mode == 0 and owner:
                    if owner in modelspace_owners:
                        return want_model
                    if owner in paperspace_owners:
                        return not want_model
                    if owner in header_names:
                        return False
                    if owner in placements:
                        # ATTRIB/SEQEND inherit their INSERT's layout; the INSERT
                        # may itself belong to a named block rather than model space.
                        handle = owner
                        continue
                return want_model
            return want_model

        return accepts

    def plot(self, *args, **kwargs):
        from .render import plot

        return plot(self, *args, **kwargs)

    def export_dxf(self, output_path: str, **kwargs):
        from .convert import to_dxf

        return to_dxf(self, output_path, **kwargs)

    def export_dwg(self, output_path: str, **kwargs):
        from .convert import to_dwg

        return to_dwg(self, output_path, **kwargs)

    def _yield_simple_entities(
        self,
        dxftype: str,
        rows: Iterable,
        build_dxf,
        entity_style_map: dict[int, tuple[int | None, int | None, int]],
        layer_color_map: dict[int, tuple[int, int | None]],
        layer_color_overrides: dict[int, tuple[int, int | None]] | None,
    ) -> Iterator[Entity]:
        """Emit ``Entity`` records for simple entity types that share the common
        decode-row → ``_attach_entity_color`` → ``Entity`` pattern.

        ``build_dxf(row)`` must return ``(handle, dxf_data_dict)``.
        """
        for row in rows:
            handle, dxf_data = build_dxf(row)
            yield Entity(
                dxftype=dxftype,
                handle=handle,
                dxf=_attach_entity_color(
                    handle,
                    dxf_data,
                    entity_style_map,
                    layer_color_map,
                    layer_color_overrides,
                    dxftype=dxftype,
                ),
            )

    def _iter_type(
        self,
        dxftype: str,
        *,
        bulk_rows: tuple[
            list[tuple[int, float, float, float, float, float, float]],
            list[tuple[int, float, float, float, float, float, float]],
            list[tuple[int, float, float, float, float]],
        ]
        | None = None,
        insert_minsert_rows: tuple[list[tuple], list[tuple]] | None = None,
        dimension_rows: list[tuple[str, tuple]] | None = None,
        include_styles: bool = True,
        entity_style_map: dict[int, tuple[int | None, int | None, int]] | None = None,
        layer_color_map: dict[int, tuple[int, int | None]] | None = None,
        layer_color_overrides: dict[int, tuple[int, int | None]] | None = None,
    ) -> Iterator[Entity]:
        decode_path = self.doc.decode_path
        if not include_styles:
            entity_style_map = {}
            layer_color_map = {}
            layer_color_overrides = None
        else:
            if entity_style_map is None:
                entity_style_map = _entity_style_map(decode_path)
            if layer_color_map is None:
                layer_color_map = _layer_color_map(decode_path)
            if layer_color_overrides is None:
                layer_color_overrides = _layer_color_overrides(
                    self.doc.decode_version,
                    entity_style_map,
                    layer_color_map,
                )

        spec = _SIMPLE_ENTITY_REGISTRY.get(dxftype)
        if spec is not None:
            ctx = spec.setup(decode_path) if spec.setup is not None else None
            for row in spec.rows_fn(decode_path):
                result = spec.build_dxf(row, ctx)
                if result is None:
                    continue
                handle, dxf_data = result
                yield Entity(
                    dxftype=dxftype,
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        dxf_data,
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype=dxftype,
                    ),
                )
            return

        if dxftype == "LINE":
            if bulk_rows is not None:
                line_rows = bulk_rows[0]
            else:
                line_rows = list(raw.decode_line_entities(decode_path))
            line_owner_handles = _line_owner_handle_map(decode_path)
            line_supplementary_handles = _line_supplementary_handles(
                line_rows, entity_style_map, layer_color_overrides
            )
            for handle, sx, sy, sz, ex, ey, ez in line_rows:
                dxf = _attach_entity_color(
                    handle,
                        {
                            "start": (sx, sy, sz),
                            "end": (ex, ey, ez),
                            "owner_handle": line_owner_handles.get(int(handle)),
                        },
                        entity_style_map,
                        layer_color_map,
                    layer_color_overrides,
                    dxftype="LINE",
                )
                if handle in line_supplementary_handles:
                    dxf["resolved_color_index"] = 9
                    dxf["resolved_true_color"] = None
                yield Entity(
                    dxftype="LINE",
                    handle=handle,
                    dxf=dxf,
                )
            return

        if dxftype == "ARC":
            arc_owner_handles = _arc_owner_handle_map(decode_path)
            arc_rows = bulk_rows[1] if bulk_rows is not None else raw.decode_arc_entities(decode_path)
            for handle, cx, cy, cz, radius, start_angle, end_angle in arc_rows:
                start_deg = math.degrees(start_angle)
                end_deg = math.degrees(end_angle)
                yield Entity(
                    dxftype="ARC",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "center": (cx, cy, cz),
                            "radius": radius,
                            "start_angle": start_deg,
                            "end_angle": end_deg,
                            "owner_handle": arc_owner_handles.get(int(handle)),
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="ARC",
                    ),
                )
            return

        if dxftype == "LWPOLYLINE":
            lwpolyline_owner_handles = _lwpolyline_owner_handle_map(decode_path)
            for (
                handle,
                flags,
                points,
                bulges,
                widths,
                const_width,
            ) in raw.decode_lwpolyline_entities(decode_path):
                points3d = [(x, y, 0.0) for x, y in points]
                bulges_list = list(bulges)
                if len(bulges_list) < len(points3d):
                    bulges_list.extend([0.0] * (len(points3d) - len(bulges_list)))
                elif len(bulges_list) > len(points3d):
                    bulges_list = bulges_list[: len(points3d)]

                widths_list = list(widths)
                if not widths_list and const_width is not None and points3d:
                    widths_list = [(const_width, const_width)] * len(points3d)
                if len(widths_list) < len(points3d):
                    widths_list.extend([(0.0, 0.0)] * (len(points3d) - len(widths_list)))
                elif len(widths_list) > len(points3d):
                    widths_list = widths_list[: len(points3d)]
                yield Entity(
                    dxftype="LWPOLYLINE",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "points": points3d,
                            "flags": flags,
                            "closed": _lwpolyline_closed(flags),
                            "bulges": bulges_list,
                            "widths": widths_list,
                            "const_width": const_width,
                            "owner_handle": lwpolyline_owner_handles.get(int(handle)),
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="LWPOLYLINE",
                    ),
                )
            return

        if dxftype == "POLYLINE_2D":
            interpreted_map = _polyline_2d_interpreted_map(decode_path)
            interpolated_points_map = _polyline_2d_interpolated_points_map(
                decode_path, interpreted_map
            )
            polyline_sequence_map, _, _ = _polyline_sequence_relationships(decode_path)
            for handle, flags, vertices in raw.decode_polyline_2d_with_vertex_data(decode_path):
                points = []
                bulges = []
                widths = []
                tangent_dirs = []
                vertex_flags = []
                for vertex in vertices:
                    (
                        x,
                        y,
                        z,
                        start_width,
                        end_width,
                        bulge,
                        tangent_dir,
                        vertex_flag,
                    ) = vertex
                    points.append((x, y, z))
                    bulges.append(bulge)
                    widths.append((start_width, end_width))
                    tangent_dirs.append(tangent_dir)
                    vertex_flags.append(int(vertex_flag))

                flags_info = _polyline_2d_flags_info(int(flags))
                interpreted = interpreted_map.get(int(handle))
                curve_type = None
                curve_type_label = None
                if interpreted is not None:
                    flags_info.update(
                        {
                            "closed": bool(interpreted.get("closed", flags_info["closed"])),
                            "curve_fit": bool(interpreted.get("curve_fit", flags_info["curve_fit"])),
                            "spline_fit": bool(interpreted.get("spline_fit", flags_info["spline_fit"])),
                            "is_3d_polyline": bool(
                                interpreted.get("is_3d_polyline", flags_info["is_3d_polyline"])
                            ),
                            "is_3d_mesh": bool(
                                interpreted.get("is_3d_mesh", flags_info["is_3d_mesh"])
                            ),
                            "is_closed_mesh": bool(
                                interpreted.get("is_closed_mesh", flags_info["is_closed_mesh"])
                            ),
                            "is_polyface_mesh": bool(
                                interpreted.get("is_polyface_mesh", flags_info["is_polyface_mesh"])
                            ),
                            "continuous_linetype": bool(
                                interpreted.get(
                                    "continuous_linetype",
                                    flags_info["continuous_linetype"],
                                )
                            ),
                        }
                    )
                    if interpreted.get("curve_type") is not None:
                        curve_type = int(interpreted["curve_type"])
                    if interpreted.get("curve_type_label") is not None:
                        curve_type_label = str(interpreted["curve_type_label"])

                closed = bool(flags_info["closed"])
                if closed and len(points) > 1 and points[0] == points[-1]:
                    points = _strip_duplicate_closure_point(points)
                    if bulges:
                        bulges.pop()
                    if widths:
                        widths.pop()
                    if tangent_dirs:
                        tangent_dirs.pop()
                    if vertex_flags:
                        vertex_flags.pop()

                should_interpolate = _polyline_2d_should_interpolate(
                    bool(flags_info["curve_fit"]),
                    bool(flags_info["spline_fit"]),
                    curve_type_label,
                )
                interpolated_points = list(interpolated_points_map.get(int(handle), []))
                interpolation_applied = bool(interpolated_points)
                sequence_info = polyline_sequence_map.get(int(handle), {})

                yield Entity(
                    dxftype="POLYLINE_2D",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "points": points,
                            "flags": int(flags),
                            "closed": closed,
                            "bulges": bulges,
                            "widths": widths,
                            "tangent_dirs": tangent_dirs,
                            "vertex_flags": vertex_flags,
                            "curve_type": curve_type,
                            "curve_type_label": curve_type_label,
                            "curve_fit": bool(flags_info["curve_fit"]),
                            "spline_fit": bool(flags_info["spline_fit"]),
                            "is_3d_polyline": bool(flags_info["is_3d_polyline"]),
                            "is_3d_mesh": bool(flags_info["is_3d_mesh"]),
                            "is_closed_mesh": bool(flags_info["is_closed_mesh"]),
                            "is_polyface_mesh": bool(flags_info["is_polyface_mesh"]),
                            "continuous_linetype": bool(flags_info["continuous_linetype"]),
                            "should_interpolate": should_interpolate,
                            "interpolation_applied": interpolation_applied,
                            "interpolated_points": interpolated_points,
                            "vertex_handles": list(sequence_info.get("vertex_handles", [])),
                            "seqend_handle": sequence_info.get("seqend_handle"),
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="POLYLINE_2D",
                    ),
                )
            return

        if dxftype == "VERTEX_2D":
            _, vertex_owner_map, _ = _polyline_sequence_relationships(decode_path)
            for (
                handle,
                flags,
                x,
                y,
                z,
                start_width,
                end_width,
                bulge,
                tangent_dir,
            ) in raw.decode_vertex_2d_entities(decode_path):
                owner_handle, owner_type = vertex_owner_map.get(int(handle), (None, None))
                yield Entity(
                    dxftype="VERTEX_2D",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "position": (x, y, z),
                            "flags": int(flags),
                            "start_width": float(start_width),
                            "end_width": float(end_width),
                            "bulge": float(bulge),
                            "tangent_dir": float(tangent_dir),
                            "owner_handle": owner_handle,
                            "owner_type": owner_type,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="VERTEX_2D",
                    ),
                )
            return

        if dxftype == "POLYLINE_3D":
            polyline_sequence_map, _, _ = _polyline_sequence_relationships(decode_path)
            for handle, flags_70_bits, closed, points in raw.decode_polyline_3d_with_vertices(
                decode_path
            ):
                sequence_info = polyline_sequence_map.get(int(handle), {})
                yield Entity(
                    dxftype="POLYLINE_3D",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "points": list(points),
                            "flags": int(flags_70_bits),
                            "closed": bool(closed),
                            "vertex_handles": list(sequence_info.get("vertex_handles", [])),
                            "seqend_handle": sequence_info.get("seqend_handle"),
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="POLYLINE_3D",
                    ),
                )
            return

        if dxftype == "VERTEX_3D":
            _, vertex_owner_map, _ = _polyline_sequence_relationships(decode_path)
            for handle, flags, x, y, z in raw.decode_vertex_3d_entities(decode_path):
                owner_handle, owner_type = vertex_owner_map.get(int(handle), (None, None))
                yield Entity(
                    dxftype="VERTEX_3D",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "position": (x, y, z),
                            "flags": int(flags),
                            "owner_handle": owner_handle,
                            "owner_type": owner_type,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="VERTEX_3D",
                    ),
                )
            return

        if dxftype == "POLYLINE_MESH":
            polyline_sequence_map, _, _ = _polyline_sequence_relationships(decode_path)
            for (
                handle,
                flags,
                m_vertex_count,
                n_vertex_count,
                closed,
                points,
            ) in raw.decode_polyline_mesh_with_vertices(decode_path):
                sequence_info = polyline_sequence_map.get(int(handle), {})
                yield Entity(
                    dxftype="POLYLINE_MESH",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "points": list(points),
                            "flags": int(flags),
                            "m_vertex_count": int(m_vertex_count),
                            "n_vertex_count": int(n_vertex_count),
                            "closed": bool(closed),
                            "vertex_handles": list(sequence_info.get("vertex_handles", [])),
                            "seqend_handle": sequence_info.get("seqend_handle"),
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="POLYLINE_MESH",
                    ),
                )
            return

        if dxftype == "VERTEX_MESH":
            _, vertex_owner_map, _ = _polyline_sequence_relationships(decode_path)
            for handle, flags, x, y, z in raw.decode_vertex_mesh_entities(decode_path):
                owner_handle, owner_type = vertex_owner_map.get(int(handle), (None, None))
                yield Entity(
                    dxftype="VERTEX_MESH",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "position": (x, y, z),
                            "flags": int(flags),
                            "owner_handle": owner_handle,
                            "owner_type": owner_type,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="VERTEX_MESH",
                    ),
                )
            return

        if dxftype == "POLYLINE_PFACE":
            polyline_sequence_map, _, _ = _polyline_sequence_relationships(decode_path)
            for (
                handle,
                num_vertices,
                num_faces,
                vertices,
                faces,
            ) in raw.decode_polyline_pface_with_faces(decode_path):
                sequence_info = polyline_sequence_map.get(int(handle), {})
                yield Entity(
                    dxftype="POLYLINE_PFACE",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "num_vertices": int(num_vertices),
                            "num_faces": int(num_faces),
                            "vertices": list(vertices),
                            "faces": list(faces),
                            "vertex_handles": list(sequence_info.get("vertex_handles", [])),
                            "face_handles": list(sequence_info.get("face_handles", [])),
                            "seqend_handle": sequence_info.get("seqend_handle"),
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="POLYLINE_PFACE",
                    ),
                )
            return

        if dxftype == "VERTEX_PFACE":
            _, vertex_owner_map, _ = _polyline_sequence_relationships(decode_path)
            for handle, flags, x, y, z in raw.decode_vertex_pface_entities(decode_path):
                owner_handle, owner_type = vertex_owner_map.get(int(handle), (None, None))
                yield Entity(
                    dxftype="VERTEX_PFACE",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "position": (x, y, z),
                            "flags": int(flags),
                            "owner_handle": owner_handle,
                            "owner_type": owner_type,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="VERTEX_PFACE",
                    ),
                )
            return

        if dxftype == "VERTEX_PFACE_FACE":
            _, vertex_owner_map, _ = _polyline_sequence_relationships(decode_path)
            for handle, index1, index2, index3, index4 in raw.decode_vertex_pface_face_entities(
                decode_path
            ):
                owner_handle, owner_type = vertex_owner_map.get(int(handle), (None, None))
                yield Entity(
                    dxftype="VERTEX_PFACE_FACE",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "indices": (
                                int(index1),
                                int(index2),
                                int(index3),
                                int(index4),
                            ),
                            "owner_handle": owner_handle,
                            "owner_type": owner_type,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="VERTEX_PFACE_FACE",
                    ),
                )
            return

        if dxftype == "3DSOLID":
            acis_candidate_map = _acis_candidate_handles_map(decode_path)
            acis_record_map = _acis_candidate_record_map(decode_path)
            for row in raw.decode_3dsolid_entities(decode_path):
                if not row:
                    continue
                handle = int(row[0])
                acis_handles = _normalize_int_handles(row[1] if len(row) >= 2 else [])
                dxf = _attach_entity_color(
                    handle,
                    {
                        "acis_handles": acis_handles,
                    },
                    entity_style_map,
                    layer_color_map,
                    layer_color_overrides,
                    dxftype="3DSOLID",
                )
                layer_handle = dxf.get("layer_handle")
                if isinstance(layer_handle, int):
                    dxf["acis_handles"] = [h for h in acis_handles if h != layer_handle]
                candidate_handles = list(acis_candidate_map.get(handle, ()))
                dxf.update(_build_acis_entity_payload(handle, candidate_handles, acis_record_map))
                yield Entity(
                    dxftype="3DSOLID",
                    handle=handle,
                    dxf=dxf,
                )
            return

        if dxftype == "BODY":
            acis_candidate_map = _acis_candidate_handles_map(decode_path)
            acis_record_map = _acis_candidate_record_map(decode_path)
            for row in raw.decode_body_entities(decode_path):
                if not row:
                    continue
                handle = int(row[0])
                acis_handles = _normalize_int_handles(row[1] if len(row) >= 2 else [])
                dxf = _attach_entity_color(
                    handle,
                    {
                        "acis_handles": acis_handles,
                    },
                    entity_style_map,
                    layer_color_map,
                    layer_color_overrides,
                    dxftype="BODY",
                )
                layer_handle = dxf.get("layer_handle")
                if isinstance(layer_handle, int):
                    dxf["acis_handles"] = [h for h in acis_handles if h != layer_handle]
                candidate_handles = list(acis_candidate_map.get(handle, ()))
                dxf.update(_build_acis_entity_payload(handle, candidate_handles, acis_record_map))
                yield Entity(
                    dxftype="BODY",
                    handle=handle,
                    dxf=dxf,
                )
            return

        if dxftype == "LONG_TRANSACTION":
            long_tx_record_map = _long_transaction_record_map(decode_path)
            header_map = _object_headers_with_type_map(decode_path)
            for row in raw.decode_long_transaction_entities(decode_path):
                if not row:
                    continue
                handle = int(row[0])
                owner_handle = None
                if len(row) >= 2 and row[1] is not None:
                    try:
                        owner_handle = int(row[1])
                    except Exception:
                        owner_handle = None
                reactor_handles = _normalize_int_handles(row[2] if len(row) >= 3 else [])
                xdic_obj_handle = None
                if len(row) >= 4 and row[3] is not None:
                    try:
                        xdic_obj_handle = int(row[3])
                    except Exception:
                        xdic_obj_handle = None
                ltype_handle = None
                if len(row) >= 5 and row[4] is not None:
                    try:
                        ltype_handle = int(row[4])
                    except Exception:
                        ltype_handle = None
                plotstyle_handle = None
                if len(row) >= 6 and row[5] is not None:
                    try:
                        plotstyle_handle = int(row[5])
                    except Exception:
                        plotstyle_handle = None
                material_handle = None
                if len(row) >= 7 and row[6] is not None:
                    try:
                        material_handle = int(row[6])
                    except Exception:
                        material_handle = None
                extra_handles = _normalize_int_handles(row[7] if len(row) >= 8 else [])
                decoded_handle_refs = _normalize_int_handles(
                    [
                        owner_handle,
                        *reactor_handles,
                        xdic_obj_handle,
                        ltype_handle,
                        plotstyle_handle,
                        material_handle,
                        *extra_handles,
                    ]
                )
                dxf_data = {
                    "owner_handle": owner_handle,
                    "reactor_handles": reactor_handles,
                    "xdic_obj_handle": xdic_obj_handle,
                    "ltype_handle": ltype_handle,
                    "plotstyle_handle": plotstyle_handle,
                    "material_handle": material_handle,
                    "extra_handles": extra_handles,
                    "decoded_handle_refs": decoded_handle_refs,
                    "decoded_handle_ref_details": _handle_ref_details(
                        decoded_handle_refs, header_map
                    ),
                }
                record_info = long_tx_record_map.get(handle)
                if record_info is not None:
                    dxf_data.update(record_info)
                yield Entity(
                    dxftype="LONG_TRANSACTION",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        dxf_data,
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="LONG_TRANSACTION",
                    ),
                )
            return

        if dxftype == "REGION":
            acis_candidate_map = _acis_candidate_handles_map(decode_path)
            acis_record_map = _acis_candidate_record_map(decode_path)
            for row in raw.decode_region_entities(decode_path):
                if not row:
                    continue
                handle = int(row[0])
                acis_handles = _normalize_int_handles(row[1] if len(row) >= 2 else [])
                dxf = _attach_entity_color(
                    handle,
                    {
                        "acis_handles": acis_handles,
                    },
                    entity_style_map,
                    layer_color_map,
                    layer_color_overrides,
                    dxftype="REGION",
                )
                layer_handle = dxf.get("layer_handle")
                if isinstance(layer_handle, int):
                    dxf["acis_handles"] = [h for h in acis_handles if h != layer_handle]
                candidate_handles = list(acis_candidate_map.get(handle, ()))
                dxf.update(_build_acis_entity_payload(handle, candidate_handles, acis_record_map))
                yield Entity(
                    dxftype="REGION",
                    handle=handle,
                    dxf=dxf,
                )
            return

        if dxftype == "CIRCLE":
            circle_owner_handles = _circle_owner_handle_map(decode_path)
            if bulk_rows is not None:
                circle_rows = bulk_rows[2]
            else:
                circle_rows = list(raw.decode_circle_entities(decode_path))
            circle_supplementary_handles = _circle_supplementary_handles(
                circle_rows, entity_style_map, layer_color_overrides
            )
            for handle, cx, cy, cz, radius in circle_rows:
                dxf = _attach_entity_color(
                    handle,
                    {
                        "center": (cx, cy, cz),
                        "radius": radius,
                        "owner_handle": circle_owner_handles.get(int(handle)),
                    },
                    entity_style_map,
                    layer_color_map,
                    layer_color_overrides,
                    dxftype="CIRCLE",
                )
                if handle in circle_supplementary_handles:
                    dxf["resolved_color_index"] = 9
                    dxf["resolved_true_color"] = None
                yield Entity(
                    dxftype="CIRCLE",
                    handle=handle,
                    dxf=dxf,
                )
            return

        if dxftype == "SPLINE":
            for (
                handle,
                flags_data,
                tolerance_data,
                knots,
                control_points,
                weights,
                fit_points,
            ) in raw.decode_spline_entities(decode_path):
                scenario, degree, rational, closed, periodic = flags_data
                fit_tolerance, knot_tolerance, ctrl_tolerance = tolerance_data
                points = list(fit_points if len(fit_points) >= 2 else control_points)
                if closed and len(points) > 1 and points[0] != points[-1]:
                    points.append(points[0])
                yield Entity(
                    dxftype="SPLINE",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "scenario": scenario,
                            "degree": degree,
                            "rational": bool(rational),
                            "closed": bool(closed),
                            "periodic": bool(periodic),
                            "fit_tolerance": fit_tolerance,
                            "knot_tolerance": knot_tolerance,
                            "ctrl_tolerance": ctrl_tolerance,
                            "knots": list(knots),
                            "control_points": list(control_points),
                            "weights": list(weights),
                            "fit_points": list(fit_points),
                            "points": points,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="SPLINE",
                    ),
                )
            return

        if dxftype == "TEXT":
            seen_text_rows: set[tuple[str, int, int, int]] = set()
            for (
                handle,
                text,
                insertion,
                alignment,
                extrusion,
                metrics,
                align_flags,
                style_handle,
                owner_handle,
            ) in raw.decode_text_entities(decode_path):
                thickness, oblique_angle, height, rotation, width_factor = metrics
                generation, horizontal_alignment, vertical_alignment = align_flags
                seen_text_rows.add(
                    (
                        str(text),
                        int(round(insertion[0] * 1000.0)),
                        int(round(insertion[1] * 1000.0)),
                        int(round(height * 1000.0)),
                    )
                )
                yield Entity(
                    dxftype="TEXT",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "text": text,
                            "insert": insertion,
                            "align_point": alignment,
                            "extrusion": extrusion,
                            "thickness": thickness,
                            "oblique": math.degrees(oblique_angle),
                            "height": height,
                            "rotation": math.degrees(rotation),
                            "width": width_factor,
                            "text_generation_flag": generation,
                            "halign": horizontal_alignment,
                            "valign": vertical_alignment,
                            "style_handle": style_handle,
                            "owner_handle": owner_handle,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="TEXT",
                    ),
                )
            proxy_text_rows = getattr(raw, "decode_proxy_graphic_text_entities", None)
            if callable(proxy_text_rows):
                try:
                    for (
                        source_handle,
                        _source_type_code,
                        chunk_index,
                        text,
                        insertion,
                        text_direction,
                        height,
                        width_factor,
                        oblique_angle,
                    ) in proxy_text_rows(decode_path):
                        key = (
                            str(text),
                            int(round(insertion[0] * 1000.0)),
                            int(round(insertion[1] * 1000.0)),
                            int(round(height * 1000.0)),
                        )
                        if key in seen_text_rows:
                            continue
                        seen_text_rows.add(key)
                        yield Entity(
                            dxftype="TEXT",
                            handle=_synthetic_embedded_text_handle(
                                int(source_handle), int(chunk_index), 0x51
                            ),
                            dxf=_attach_entity_color(
                                int(source_handle),
                                {
                                    "text": text,
                                    "insert": insertion,
                                    "align_point": None,
                                    "extrusion": (0.0, 0.0, 1.0),
                                    "thickness": 0.0,
                                    "oblique": math.degrees(float(oblique_angle)),
                                    "height": float(height),
                                    "rotation": math.degrees(
                                        math.atan2(float(text_direction[1]), float(text_direction[0]))
                                    ),
                                    "width": float(width_factor),
                                    "text_generation_flag": 0,
                                    "halign": 0,
                                    "valign": 0,
                                    "style_handle": None,
                                    "owner_handle": None,
                                },
                                entity_style_map,
                                layer_color_map,
                                layer_color_overrides,
                                dxftype="TEXT",
                            ),
                        )
                except Exception:
                    pass
            for row in _unknown_shifted_text_entities(decode_path):
                handle, text, insertion, height, rotation = row[:5]
                owner_handle = row[5] if len(row) >= 6 else None
                source_layer_handle = row[6] if len(row) >= 7 else None
                dxftype_hint = row[7] if len(row) >= 8 else None
                recovery_mode = row[8] if len(row) >= 9 else None
                if dxftype_hint == "MTEXT":
                    continue
                inferred_layer_handle = None
                if source_layer_handle is not None and _is_plausible_nearby_layer_handle(
                    decode_path,
                    source_layer_handle,
                    insertion,
                ):
                    inferred_layer_handle = source_layer_handle
                if inferred_layer_handle is None:
                    inferred_layer_handle = _infer_adjacent_recovered_text_layer_handle(
                        decode_path,
                        source_layer_handle,
                        recovery_mode,
                    )
                if inferred_layer_handle is None:
                    inferred_layer_handle = _infer_nearby_layer_handle(
                        decode_path,
                        insertion,
                    )
                key = (
                    str(text),
                    int(round(insertion[0] * 1000.0)),
                    int(round(insertion[1] * 1000.0)),
                    int(round(height * 1000.0)),
                )
                if key in seen_text_rows:
                    continue
                seen_text_rows.add(key)
                yield Entity(
                    dxftype="TEXT",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "text": text,
                            "insert": insertion,
                            "align_point": None,
                            "extrusion": (0.0, 0.0, 1.0),
                            "thickness": 0.0,
                            "oblique": 0.0,
                            "height": height,
                            "rotation": rotation,
                            "width": 1.0,
                            "text_generation_flag": 0,
                            "halign": 0,
                            "valign": 0,
                            "style_handle": None,
                            "owner_handle": owner_handle,
                            "layer_handle": inferred_layer_handle,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="TEXT",
                    ),
                )
            return

        if dxftype == "ATTRIB":
            for (
                handle,
                text,
                tag,
                prompt,
                insertion,
                alignment,
                extrusion,
                metrics,
                align_flags,
                attrib_flags,
                lock_position,
                style_owner_handles,
            ) in raw.decode_attrib_entities(decode_path):
                thickness, oblique_angle, height, rotation, width_factor = metrics
                generation, horizontal_alignment, vertical_alignment = align_flags
                style_handle = None
                owner_handle = None
                if isinstance(style_owner_handles, tuple):
                    if len(style_owner_handles) >= 1:
                        style_handle = style_owner_handles[0]
                    if len(style_owner_handles) >= 2:
                        owner_handle = style_owner_handles[1]
                owner_handle_value = None
                if owner_handle is not None:
                    try:
                        owner_handle_value = int(owner_handle)
                    except Exception:
                        owner_handle_value = None
                yield Entity(
                    dxftype="ATTRIB",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "text": text,
                            "tag": tag,
                            "prompt": prompt,
                            "insert": insertion,
                            "align_point": alignment,
                            "extrusion": extrusion,
                            "thickness": thickness,
                            "oblique": math.degrees(oblique_angle),
                            "height": height,
                            "rotation": math.degrees(rotation),
                            "width": width_factor,
                            "text_generation_flag": generation,
                            "halign": horizontal_alignment,
                            "valign": vertical_alignment,
                            "style_handle": style_handle,
                            "attribute_flags": int(attrib_flags),
                            "lock_position": bool(lock_position),
                            "owner_handle": owner_handle_value,
                            "owner_type": "INSERT" if owner_handle_value is not None else None,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="ATTRIB",
                    ),
                )
            return

        if dxftype == "ATTDEF":
            for (
                handle,
                text,
                tag,
                prompt,
                insertion,
                alignment,
                extrusion,
                metrics,
                align_flags,
                attrib_flags,
                lock_position,
                style_owner_handles,
            ) in raw.decode_attdef_entities(decode_path):
                thickness, oblique_angle, height, rotation, width_factor = metrics
                generation, horizontal_alignment, vertical_alignment = align_flags
                style_handle = None
                owner_handle = None
                if isinstance(style_owner_handles, tuple):
                    if len(style_owner_handles) >= 1:
                        style_handle = style_owner_handles[0]
                    if len(style_owner_handles) >= 2:
                        owner_handle = style_owner_handles[1]
                owner_handle_value = None
                if owner_handle is not None:
                    try:
                        owner_handle_value = int(owner_handle)
                    except Exception:
                        owner_handle_value = None
                yield Entity(
                    dxftype="ATTDEF",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "text": text,
                            "tag": tag,
                            "prompt": prompt,
                            "insert": insertion,
                            "align_point": alignment,
                            "extrusion": extrusion,
                            "thickness": thickness,
                            "oblique": math.degrees(oblique_angle),
                            "height": height,
                            "rotation": math.degrees(rotation),
                            "width": width_factor,
                            "text_generation_flag": generation,
                            "halign": horizontal_alignment,
                            "valign": vertical_alignment,
                            "style_handle": style_handle,
                            "attribute_flags": int(attrib_flags),
                            "lock_position": bool(lock_position),
                            "owner_handle": owner_handle_value,
                            "owner_type": "BLOCK" if owner_handle_value is not None else None,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="ATTDEF",
                    ),
                )
            return

        if dxftype == "MTEXT":
            seen_mtext_rows: set[tuple[str, int, int, int]] = set()
            for (
                handle,
                text,
                insertion,
                extrusion,
                x_axis_dir,
                rect_width,
                text_height,
                attachment,
                drawing_dir,
                background_data,
                owner_handle,
            ) in raw.decode_mtext_entities(decode_path):
                (
                    background_flags,
                    background_scale_factor,
                    background_color_index,
                    background_true_color,
                    background_transparency,
                ) = background_data
                rotation = math.degrees(math.atan2(x_axis_dir[1], x_axis_dir[0]))
                plain_text = _decode_mtext_plain_text(text)
                seen_mtext_rows.add(
                    (
                        str(plain_text),
                        int(round(insertion[0] * 1000.0)),
                        int(round(insertion[1] * 1000.0)),
                        int(round(text_height * 1000.0)),
                    )
                )
                yield Entity(
                    dxftype="MTEXT",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "text": plain_text,
                            "raw_text": text,
                            "insert": insertion,
                            "extrusion": extrusion,
                            "text_direction": x_axis_dir,
                            "rotation": rotation,
                            "rect_width": rect_width,
                            "char_height": text_height,
                            "attachment_point": attachment,
                            "drawing_direction": drawing_dir,
                            "background_flags": background_flags,
                            "background_scale_factor": background_scale_factor,
                            "background_color_index": background_color_index,
                            "background_true_color": background_true_color,
                            "background_transparency": background_transparency,
                            "owner_handle": owner_handle,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="MTEXT",
                    ),
                )
            for row in _unknown_shifted_text_entities(decode_path):
                handle, text, insertion, height, rotation = row[:5]
                owner_handle = row[5] if len(row) >= 6 else None
                source_layer_handle = row[6] if len(row) >= 7 else None
                dxftype_hint = row[7] if len(row) >= 8 else None
                recovery_mode = row[8] if len(row) >= 9 else None
                if dxftype_hint != "MTEXT":
                    continue
                inferred_layer_handle = None
                if source_layer_handle is not None and _is_plausible_nearby_layer_handle(
                    decode_path,
                    source_layer_handle,
                    insertion,
                ):
                    inferred_layer_handle = source_layer_handle
                if inferred_layer_handle is None:
                    inferred_layer_handle = _infer_nearby_layer_handle(
                        decode_path,
                        insertion,
                    )
                key = (
                    str(text),
                    int(round(insertion[0] * 1000.0)),
                    int(round(insertion[1] * 1000.0)),
                    int(round(height * 1000.0)),
                )
                if key in seen_mtext_rows:
                    continue
                seen_mtext_rows.add(key)
                angle = math.radians(rotation)
                yield Entity(
                    dxftype="MTEXT",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "text": text,
                            "raw_text": text,
                            "insert": insertion,
                            "extrusion": (0.0, 0.0, 1.0),
                            "text_direction": (math.cos(angle), math.sin(angle), 0.0),
                            "rotation": rotation,
                            "rect_width": 0.0,
                            "char_height": height,
                            "attachment_point": 1,
                            "drawing_direction": 1,
                            "background_flags": 0,
                            "background_scale_factor": 0.0,
                            "background_color_index": None,
                            "background_true_color": None,
                            "background_transparency": None,
                            "owner_handle": owner_handle,
                            "layer_handle": inferred_layer_handle,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="MTEXT",
                    ),
                )
            return

        if dxftype == "HATCH":
            hatch_patterns = _hatch_pattern_map(decode_path)
            for (
                handle,
                name,
                solid_fill,
                associative,
                elevation,
                extrusion,
                path_rows,
            ) in raw.decode_hatch_entities(decode_path):
                paths = []
                for closed, points in path_rows:
                    path_points = [(x, y, elevation) for x, y in points]
                    if bool(closed) and len(path_points) > 1 and path_points[0] != path_points[-1]:
                        path_points.append(path_points[0])
                    paths.append(
                        {
                            "closed": bool(closed),
                            "points": path_points,
                        }
                    )
                hatch_dxf = {
                    "pattern_name": name,
                    "solid_fill": bool(solid_fill),
                    "associative": bool(associative),
                    "elevation": elevation,
                    "extrusion": extrusion,
                    "paths": paths,
                }
                pattern = hatch_patterns.get(handle)
                if pattern is not None:
                    hatch_dxf.update(pattern)
                yield Entity(
                    dxftype="HATCH",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        hatch_dxf,
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="HATCH",
                    ),
                )
            return

        if dxftype == "MLINE":
            for (
                handle,
                scale,
                justification,
                base_point,
                extrusion,
                open_closed,
                lines_in_style,
                vertices,
                mlinestyle_handle,
            ) in raw.decode_mline_entities(decode_path):
                vertices_list = list(vertices)
                points = [vertex[0] for vertex in vertices_list if len(vertex) >= 1]
                vertex_directions = [vertex[1] for vertex in vertices_list if len(vertex) >= 2]
                miter_directions = [vertex[2] for vertex in vertices_list if len(vertex) >= 3]
                flags = int(open_closed)
                closed = flags == 3 or bool(flags & 0x02)
                yield Entity(
                    dxftype="MLINE",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        {
                            "scale": scale,
                            "justification": int(justification),
                            "base_point": base_point,
                            "extrusion": extrusion,
                            "flags": flags,
                            "closed": closed,
                            "line_count": int(lines_in_style),
                            "points": points,
                            "vertex_directions": vertex_directions,
                            "miter_directions": miter_directions,
                            "mlinestyle_handle": mlinestyle_handle,
                        },
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="MLINE",
                    ),
                )
            return

        if dxftype == "MINSERT":
            rows = (
                insert_minsert_rows[1]
                if insert_minsert_rows is not None
                else raw.decode_minsert_entities(decode_path)
            )
            for row in rows:
                if len(row) == 9 and isinstance(row[8], tuple):
                    (
                        handle,
                        px,
                        py,
                        pz,
                        sx,
                        sy,
                        sz,
                        rotation,
                        array_info,
                    ) = row
                    (
                        num_columns,
                        num_rows,
                        column_spacing,
                        row_spacing,
                        name,
                    ) = array_info
                elif len(row) == 12:
                    (
                        handle,
                        px,
                        py,
                        pz,
                        sx,
                        sy,
                        sz,
                        rotation,
                        num_columns,
                        num_rows,
                        column_spacing,
                        row_spacing,
                    ) = row
                    name = None
                else:
                    # Backward-compatible shape from older extension builds.
                    (
                        handle,
                        px,
                        py,
                        pz,
                        sx,
                        sy,
                        sz,
                        rotation,
                        num_columns,
                        num_rows,
                        column_spacing,
                        row_spacing,
                        name,
                    ) = row
                dxf = {
                    "insert": (px, py, pz),
                    "xscale": sx,
                    "yscale": sy,
                    "zscale": sz,
                    "rotation": math.degrees(rotation),
                    "column_count": num_columns,
                    "row_count": num_rows,
                    "column_spacing": column_spacing,
                    "row_spacing": row_spacing,
                }
                if isinstance(name, str) and name:
                    dxf["name"] = name
                yield Entity(
                    dxftype="MINSERT",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        dxf,
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="MINSERT",
                    ),
                )
            return

        if dxftype == "INSERT":
            owner_handle_map = _insert_owner_handle_map(decode_path)
            rows = (
                insert_minsert_rows[0]
                if insert_minsert_rows is not None
                else raw.decode_insert_entities(decode_path)
            )
            for row in rows:
                if len(row) == 8:
                    handle, px, py, pz, sx, sy, sz, rotation = row
                    name = None
                    owner_handle = owner_handle_map.get(int(handle))
                else:
                    handle, px, py, pz, sx, sy, sz, rotation, name, *rest = row
                    owner_handle = owner_handle_map.get(int(handle))
                    if rest:
                        raw_owner_handle = rest[0]
                        try:
                            owner_handle = int(raw_owner_handle) if raw_owner_handle is not None else None
                        except Exception:
                            owner_handle = owner_handle_map.get(int(handle))
                dxf = {
                    "insert": (px, py, pz),
                    "xscale": sx,
                    "yscale": sy,
                    "zscale": sz,
                    "rotation": math.degrees(rotation),
                }
                if isinstance(name, str) and name:
                    dxf["name"] = name
                if owner_handle is not None:
                    dxf["owner_handle"] = owner_handle
                yield Entity(
                    dxftype="INSERT",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        dxf,
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="INSERT",
                    ),
                )
            return

        if dxftype == "DIMENSION":
            # Some decoder builds return only LINEAR rows from the bulk API.
            # Merge subtype-specific decoders by handle to avoid silently
            # dropping DIM_* entities.
            anonymous_block_name_map = _block_header_name_map(decode_path)
            block_text_heights = _block_text_height_map(decode_path)
            rows_by_handle: dict[int, tuple[str, tuple]] = {}

            def _put_row(dimtype: str, row: tuple) -> None:
                if not isinstance(row, tuple) or len(row) == 0:
                    return
                try:
                    handle = int(row[0])
                except Exception:
                    return
                normalized_type = str(dimtype).upper()
                existing = rows_by_handle.get(handle)
                if existing is None:
                    rows_by_handle[handle] = (normalized_type, row)
                    return
                existing_type, _ = existing
                # Prefer subtype decoders over generic LINEAR when available.
                if existing_type == "LINEAR" and normalized_type != "LINEAR":
                    rows_by_handle[handle] = (normalized_type, row)

            bulk_decode_ok = False
            bulk_types: set[str] = set()
            bulk_rows_iter: list[tuple[str, tuple]]
            if dimension_rows is not None:
                bulk_rows_iter = list(dimension_rows)
                bulk_decode_ok = True
            else:
                try:
                    bulk_rows_iter = list(raw.decode_dimension_entities(decode_path))
                    bulk_decode_ok = True
                except Exception:
                    bulk_rows_iter = []
                    bulk_decode_ok = False
            for dimtype, row in bulk_rows_iter:
                normalized_type = str(dimtype).upper()
                bulk_types.add(normalized_type)
                _put_row(normalized_type, row)
            if not bulk_rows_iter:
                bulk_decode_ok = False

            use_legacy_subtype_fallback = (
                not bulk_decode_ok
                or not rows_by_handle
                or bulk_types.issubset({"LINEAR"})
            )

            def _append_rows(dimtype: str, decode_fn) -> None:
                try:
                    rows = decode_fn(decode_path)
                except Exception:
                    rows = []
                for row in rows:
                    _put_row(dimtype, row)

            if use_legacy_subtype_fallback:
                _append_rows("LINEAR", raw.decode_dim_linear_entities)
                _append_rows("ORDINATE", raw.decode_dim_ordinate_entities)
                _append_rows("ALIGNED", raw.decode_dim_aligned_entities)
                _append_rows("ANG3PT", raw.decode_dim_ang3pt_entities)
                _append_rows("ANG2LN", raw.decode_dim_ang2ln_entities)
                _append_rows("RADIUS", raw.decode_dim_radius_entities)
                _append_rows("DIAMETER", raw.decode_dim_diameter_entities)

            dimension_rows = sorted(rows_by_handle.values(), key=lambda item: int(item[1][0]))
            for dimtype, row in dimension_rows:
                (
                    handle,
                    user_text,
                    point10,
                    point13,
                    point14,
                    text_midpoint,
                    insert_point,
                    transforms,
                    angles,
                    common_data,
                    handle_data,
                    *extra_fields,
                ) = row
                # ezdwg >= 0.12.4 appends the type-specific extra definition
                # points (DXF codes 15/16) for angular dimensions; older rows
                # (or fallback rows built by tests) have 11 elements.
                point15 = point16 = None
                if extra_fields and isinstance(extra_fields[0], tuple) and len(extra_fields[0]) == 2:
                    point15, point16 = extra_fields[0]
                extrusion, insert_scale = transforms
                text_rotation, horizontal_direction, ext_line_rotation, dim_rotation = angles
                (
                    dim_flags,
                    actual_measurement,
                    attachment_point,
                    line_spacing_style,
                    line_spacing_factor,
                    insert_rotation,
                ) = common_data
                dimstyle_handle, anonymous_block_handle = handle_data
                common_dxf = _build_dimension_common_dxf(
                    user_text=user_text,
                    text_midpoint=text_midpoint,
                    insert_point=insert_point,
                    extrusion=extrusion,
                    insert_scale=insert_scale,
                    text_rotation=text_rotation,
                    horizontal_direction=horizontal_direction,
                    dim_flags=dim_flags,
                    actual_measurement=actual_measurement,
                    attachment_point=attachment_point,
                    line_spacing_style=line_spacing_style,
                    line_spacing_factor=line_spacing_factor,
                    insert_rotation=insert_rotation,
                    dimstyle_handle=dimstyle_handle,
                    anonymous_block_handle=anonymous_block_handle,
                )
                dim_dxf = {
                    "dimtype": dimtype,
                    "defpoint": point10,
                    "defpoint2": point13,
                    "defpoint3": point14,
                    "oblique_angle": math.degrees(ext_line_rotation),
                    "angle": math.degrees(dim_rotation),
                }
                if point15 is not None:
                    dim_dxf["defpoint4"] = tuple(point15)
                if point16 is not None:
                    dim_dxf["defpoint5"] = (float(point16[0]), float(point16[1]), 0.0)
                dim_dxf.update(common_dxf)
                if anonymous_block_handle is not None:
                    try:
                        block_handle = int(anonymous_block_handle)
                        anonymous_block_name = anonymous_block_name_map.get(
                            block_handle
                        )
                        block_text_height = block_text_heights.get(block_handle)
                    except Exception:
                        anonymous_block_name = None
                        block_text_height = None
                    if isinstance(anonymous_block_name, str) and anonymous_block_name:
                        dim_dxf["anonymous_block_name"] = anonymous_block_name
                    if block_text_height is not None:
                        dim_dxf["char_height"] = block_text_height
                        dim_dxf["char_height_source"] = "anonymous_block"
                dim_dxf["common"] = dict(common_dxf)
                yield Entity(
                    dxftype="DIMENSION",
                    handle=handle,
                    dxf=_attach_entity_color(
                        handle,
                        dim_dxf,
                        entity_style_map,
                        layer_color_map,
                        layer_color_overrides,
                        dxftype="DIMENSION",
                    ),
                )
            return

        raise ValueError(
            f"unsupported entity type: {dxftype}. "
            "Supported types: LINE, LWPOLYLINE, POLYLINE_2D, VERTEX_2D, POLYLINE_3D, VERTEX_3D, POLYLINE_MESH, VERTEX_MESH, POLYLINE_PFACE, VERTEX_PFACE, VERTEX_PFACE_FACE, SEQEND, 3DFACE, SOLID, TRACE, SHAPE, 3DSOLID, BODY, VIEWPORT, OLEFRAME, OLE2FRAME, LONG_TRANSACTION, REGION, RAY, XLINE, ARC, CIRCLE, ELLIPSE, SPLINE, POINT, TEXT, ATTRIB, ATTDEF, MTEXT, LEADER, HATCH, TOLERANCE, MLINE, BLOCK, ENDBLK, INSERT, MINSERT, DIMENSION"
        )


def _seqend_owner_pair(handle: int, seqend_map: dict) -> tuple:
    pair = seqend_map.get(int(handle)) or (None, None)
    return pair[0], pair[1]


_SIMPLE_ENTITY_REGISTRY: dict[str, _SimpleEntitySpec] = {
    "3DFACE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_3dface_entities(p),
        build_dxf=lambda row, _: (
            row[0],
            {
                "points": [row[1], row[2], row[3], row[4]],
                "invisible_edge_flags": int(row[5]),
            },
        ),
    ),
    "SOLID": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_solid_entities(p),
        build_dxf=lambda row, _: (
            row[0],
            {
                "points": [row[1], row[2], row[3], row[4]],
                "thickness": row[5],
                "extrusion": row[6],
            },
        ),
    ),
    "TRACE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_trace_entities(p),
        build_dxf=lambda row, _: (
            row[0],
            {
                "points": [row[1], row[2], row[3], row[4]],
                "thickness": row[5],
                "extrusion": row[6],
            },
        ),
    ),
    "VIEWPORT": _SimpleEntitySpec(
        rows_fn=lambda p: _viewport_rows(p),
        build_dxf=lambda row, layer_names: _viewport_dxf(row, layer_names),
        setup=lambda p: _layer_names_by_handle(p),
    ),
    "RAY": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_ray_entities(p),
        build_dxf=lambda row, _: (row[0], {"start": row[1], "unit_vector": row[2]}),
    ),
    "IMAGE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_image_entities(p),
        build_dxf=lambda row, defs: _image_dxf(row, defs),
        setup=lambda p: _image_defs_by_handle(p),
    ),
    "XLINE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_xline_entities(p),
        build_dxf=lambda row, _: (row[0], {"start": row[1], "unit_vector": row[2]}),
    ),
    "ELLIPSE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_ellipse_entities(p),
        build_dxf=lambda row, _: (
            row[0],
            {
                "center": row[1],
                "major_axis": row[2],
                "extrusion": row[3],
                "axis_ratio": row[4],
                "start_angle": row[5],
                "end_angle": row[6],
            },
        ),
    ),
    "LEADER": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_leader_entities(p),
        build_dxf=lambda row, _: (
            row[0],
            {
                "annotation_type": int(row[1]),
                "path_type": int(row[2]),
                "points": list(row[3]),
            },
        ),
    ),
    "SHAPE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_shape_entities(p),
        build_dxf=lambda row, _: (
            row[0],
            {
                "insert": row[1],
                "scale": row[2],
                "rotation": math.degrees(row[3]),
                "width": row[4],
                "oblique": math.degrees(row[5]),
                "thickness": row[6],
                "shape_no": int(row[7]),
                "extrusion": row[8],
                "shapefile_handle": row[9],
            },
        ),
    ),
    "TOLERANCE": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_tolerance_entities(p),
        setup=lambda p: _dimstyle_map(p),
        build_dxf=lambda row, dimstyles: (
            row[0],
            {
                "text": row[1],
                "insert": row[2],
                "x_direction": row[3],
                "extrusion": row[4],
                "height": _tolerance_text_height(row[5], dimstyles.get(row[7])),
                "dimgap": row[6],
                "rotation": math.degrees(math.atan2(row[3][1], row[3][0])),
                "dimstyle_handle": row[7],
            },
        ),
    ),
    "POINT": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_point_entities(p),
        setup=lambda p: _point_owner_handle_map(p),
        build_dxf=lambda row, owners: (
            row[0],
            {
                "location": (row[1], row[2], row[3]),
                "x_axis_angle": row[4],
                "owner_handle": owners.get(int(row[0])),
            },
        ),
    ),
    "SEQEND": _SimpleEntitySpec(
        rows_fn=lambda p: _entity_handles_by_type_name(p, "SEQEND"),
        setup=lambda p: _polyline_sequence_relationships(p)[2],
        build_dxf=lambda handle, seqend_map: (
            handle,
            {
                "owner_handle": _seqend_owner_pair(handle, seqend_map)[0],
                "owner_type": _seqend_owner_pair(handle, seqend_map)[1],
            },
        ),
    ),
    "OLEFRAME": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_oleframe_entities(p),
        setup=lambda p: _oleframe_record_map(p),
        build_dxf=lambda row, record_map: (
            (int(row[0]), dict(record_map.get(int(row[0]), {}))) if row else None
        ),
    ),
    "OLE2FRAME": _SimpleEntitySpec(
        rows_fn=lambda p: raw.decode_ole2frame_entities(p),
        setup=lambda p: _ole2frame_record_map(p),
        build_dxf=lambda row, record_map: (
            (int(row[0]), dict(record_map.get(int(row[0]), {}))) if row else None
        ),
    ),
    "BLOCK": _SimpleEntitySpec(
        rows_fn=lambda p: _entity_handles_by_type_name(p, "BLOCK"),
        setup=lambda p: _block_and_endblk_name_maps(p)[0],
        build_dxf=lambda handle, name_map: (handle, {"name": name_map.get(handle)}),
    ),
    "ENDBLK": _SimpleEntitySpec(
        rows_fn=lambda p: _entity_handles_by_type_name(p, "ENDBLK"),
        setup=lambda p: _block_and_endblk_name_maps(p)[1],
        build_dxf=lambda handle, name_map: (handle, {"name": name_map.get(handle)}),
    ),
}


def _decode_mtext_plain_text(value: str) -> str:
    if not value:
        return ""

    out: list[str] = []
    i = 0
    n = len(value)
    while i < n:
        ch = value[i]

        if ch in "{}":
            i += 1
            continue
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= n:
            out.append("\\")
            break

        code = value[i + 1]
        if code in "\\{}":
            out.append(code)
            i += 2
            continue
        if code in {"P", "X"}:
            out.append("\n")
            i += 2
            continue
        if code == "~":
            out.append(" ")
            i += 2
            continue
        if code in {"L", "l", "O", "o", "K", "k"}:
            i += 2
            continue
        if code in {"U", "u"} and i + 6 < n and value[i + 2] == "+":
            hex_digits = value[i + 3 : i + 7]
            if all(c in "0123456789abcdefABCDEF" for c in hex_digits):
                out.append(chr(int(hex_digits, 16)))
                i += 7
                continue
        if code == "S":
            i += 2
            stacked: list[str] = []
            while i < n and value[i] != ";":
                token = value[i]
                if token in {"#", "^"}:
                    token = "/"
                stacked.append(token)
                i += 1
            if i < n and value[i] == ";":
                i += 1
            out.append("".join(stacked))
            continue
        if code in {"A", "C", "c", "F", "f", "H", "h", "Q", "q", "T", "t", "W", "w", "p"}:
            i += 2
            while i < n and value[i] != ";":
                i += 1
            if i < n and value[i] == ";":
                i += 1
            continue

        out.append(code)
        i += 2

    return "".join(out)


def _strip_duplicate_closure_point(
    points: list[tuple[float, float, float]],
) -> list[tuple[float, float, float]]:
    if len(points) > 1 and points[0] == points[-1]:
        return points[:-1]
    return points


def _polyline_2d_flags_info(flags: int) -> dict[str, bool]:
    value = int(flags)
    return {
        "closed": bool(value & 0x01),
        "curve_fit": bool(value & 0x02),
        "spline_fit": bool(value & 0x04),
        "is_3d_polyline": bool(value & 0x08),
        "is_3d_mesh": bool(value & 0x10),
        "is_closed_mesh": bool(value & 0x20),
        "is_polyface_mesh": bool(value & 0x40),
        "continuous_linetype": bool(value & 0x80),
    }


def _lwpolyline_closed(flags: int) -> bool:
    value = int(flags)
    # Native DWG bit 0 denotes an explicit extrusion, bit 9 denotes closure.
    return bool(value & 0x200)


def _polyline_2d_should_interpolate(
    curve_fit: bool,
    spline_fit: bool,
    curve_type_label: str | None,
) -> bool:
    if curve_fit or spline_fit:
        return True
    if curve_type_label in _POLYLINE_2D_SPLINE_CURVE_TYPES:
        return True
    return False


def _polyline_2d_interpreted_map(path: str) -> dict[int, dict[str, object]]:
    try:
        rows = raw.decode_polyline_2d_entities_interpreted(path)
    except Exception:
        return {}

    interpreted: dict[int, dict[str, object]] = {}
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 12:
            continue
        (
            handle,
            _flags,
            curve_type,
            curve_type_label,
            closed,
            curve_fit,
            spline_fit,
            is_3d_polyline,
            is_3d_mesh,
            is_closed_mesh,
            is_polyface_mesh,
            continuous_linetype,
        ) = row
        interpreted[int(handle)] = {
            "curve_type": int(curve_type),
            "curve_type_label": str(curve_type_label),
            "closed": bool(closed),
            "curve_fit": bool(curve_fit),
            "spline_fit": bool(spline_fit),
            "is_3d_polyline": bool(is_3d_polyline),
            "is_3d_mesh": bool(is_3d_mesh),
            "is_closed_mesh": bool(is_closed_mesh),
            "is_polyface_mesh": bool(is_polyface_mesh),
            "continuous_linetype": bool(continuous_linetype),
        }
    return interpreted


def _polyline_2d_interpolated_points_map(
    path: str,
    interpreted_map: dict[int, dict[str, object]],
) -> dict[int, list[tuple[float, float, float]]]:
    interpolation_handles = {
        handle
        for handle, info in interpreted_map.items()
        if _polyline_2d_should_interpolate(
            bool(info.get("curve_fit", False)),
            bool(info.get("spline_fit", False)),
            str(info.get("curve_type_label", "")),
        )
    }
    if not interpolation_handles:
        return {}

    try:
        rows = raw.decode_polyline_2d_with_vertices_interpolated(
            path, _POLYLINE_2D_INTERPOLATION_SEGMENTS
        )
    except Exception:
        return {}

    interpolated: dict[int, list[tuple[float, float, float]]] = {}
    for handle, flags, applied, points in rows:
        handle_key = int(handle)
        if handle_key not in interpolation_handles or not bool(applied):
            continue
        closed = bool(
            interpreted_map.get(handle_key, {}).get("closed", bool(int(flags) & 0x01))
        )
        points3d = list(points)
        if closed:
            points3d = _strip_duplicate_closure_point(points3d)
        interpolated[handle_key] = points3d
    return interpolated


def _image_defs_by_handle(path: str) -> dict[int, dict[str, Any]]:
    try:
        rows = raw.decode_image_defs(path)
    except Exception:
        return {}
    result = {}
    for handle, file_path, size, is_loaded, units, pixel_size in rows:
        stem = file_path.replace("\\", "/").rsplit("/", 1)[-1].rsplit(".", 1)[0]
        result[int(handle)] = {
            "image_def": stem or f"IMAGE_{int(handle)}",
            "file_path": file_path,
            "def_size": tuple(size),
            "is_loaded": bool(is_loaded),
            "resolution_units": int(units),
            "pixel_size": tuple(pixel_size),
        }
    return result


def _image_dxf(row: tuple, defs: dict[int, dict[str, Any]]) -> tuple[int, dict]:
    (
        handle,
        insert,
        u_vector,
        v_vector,
        size,
        display_props,
        clipping,
        (brightness, contrast, fade),
        clip_type,
        clip_vertices,
        image_def_handle,
        reactor_handle,
    ) = row
    definition = defs.get(int(image_def_handle), {})
    return (
        handle,
        {
            "insert": insert,
            "u_vector": u_vector,
            "v_vector": v_vector,
            "size": tuple(size),
            "display_props": int(display_props),
            "clipping": bool(clipping),
            "brightness": int(brightness),
            "contrast": int(contrast),
            "fade": int(fade),
            "clip_type": int(clip_type),
            "clip_vertices": [tuple(v) for v in clip_vertices],
            "image_def_handle": int(image_def_handle),
            "reactor_handle": int(reactor_handle),
            "image_def": definition.get("image_def"),
            "file_path": definition.get("file_path"),
        },
    )


def _build_dimension_common_dxf(
    *,
    user_text: str,
    text_midpoint: tuple[float, float, float],
    insert_point: tuple[float, float, float] | None,
    extrusion: tuple[float, float, float],
    insert_scale: tuple[float, float, float],
    text_rotation: float,
    horizontal_direction: float,
    dim_flags: int,
    actual_measurement: float | None,
    attachment_point: int | None,
    line_spacing_style: int | None,
    line_spacing_factor: float | None,
    insert_rotation: float,
    dimstyle_handle: int | None,
    anonymous_block_handle: int | None,
) -> dict:
    return {
        "text_midpoint": text_midpoint,
        "insert": insert_point,
        "extrusion": extrusion,
        "insert_scale": insert_scale,
        "text": user_text,
        "text_rotation": math.degrees(text_rotation),
        "horizontal_direction": math.degrees(horizontal_direction),
        "dim_flags": dim_flags,
        "actual_measurement": actual_measurement,
        "attachment_point": attachment_point,
        "line_spacing_style": line_spacing_style,
        "line_spacing_factor": line_spacing_factor,
        "insert_rotation": math.degrees(insert_rotation),
        "dimstyle_handle": dimstyle_handle,
        "anonymous_block_handle": anonymous_block_handle,
    }


# ---------------------------------------------------------------------------
# Legacy path-keyed maps (pure Python @lru_cache).
#
# Do not add new @lru_cache helpers here. New table/entity metadata should
# go through the shared Rust FileKey / PathFifoCache in bindings/cache.rs
# (and raw.clear_decode_cache) so invalidation and clear_decode_caches() stay
# consistent. These helpers remain until their maps are migrated.
# ---------------------------------------------------------------------------

@lru_cache(maxsize=32)
def _present_supported_types(
    path: str | None, *, include_explicit_only: bool = False
) -> tuple[str, ...]:
    if not path:
        return tuple(SUPPORTED_ENTITY_TYPES)
    try:
        headers = raw.list_object_headers_with_type(path)
    except Exception:
        return tuple(SUPPORTED_ENTITY_TYPES)

    seen: set[str] = set()
    for row in headers:
        if not isinstance(row, tuple) or len(row) < 5:
            continue
        canonical = _canonical_entity_type_name(row[4])
        if canonical is not None:
            seen.add(canonical)

    if not seen:
        present = tuple(SUPPORTED_ENTITY_TYPES)
    else:
        present = tuple(dxftype for dxftype in SUPPORTED_ENTITY_TYPES if dxftype in seen)

    if include_explicit_only:
        return present
    return tuple(dxftype for dxftype in present if dxftype not in _EXPLICIT_ONLY_ENTITY_TYPES)


def _canonical_entity_type_name(raw_name: object) -> str | None:
    name = str(raw_name).strip().upper()
    if not name:
        return None
    if name.startswith("DIM_"):
        return "DIMENSION"
    canonical = TYPE_ALIASES.get(name, name)
    if canonical in SUPPORTED_ENTITY_TYPES:
        return canonical
    return None


def _normalize_types(types: str | Iterable[str] | None, path: str | None = None) -> list[str]:
    if types is None:
        return list(_present_supported_types(path))
    if isinstance(types, str):
        tokens = re.split(r"[,\s]+", types.strip())
    else:
        tokens = list(types)

    normalized = [token.strip().upper() for token in tokens if token and token.strip()]
    normalized = [TYPE_ALIASES.get(token, token) for token in normalized]
    if not normalized:
        return list(_present_supported_types(path))

    if any(token in {"*", "ALL"} for token in normalized):
        return list(_present_supported_types(path))

    needs_glob_match = any(any(ch in token for ch in "*?[]") for token in normalized)
    candidate_types = (
        list(_present_supported_types(path, include_explicit_only=True))
        if (needs_glob_match and path is not None)
        else list(SUPPORTED_ENTITY_TYPES)
    )

    selected: list[str] = []
    seen = set()

    for token in normalized:
        if any(ch in token for ch in "*?[]"):
            matches = [
                name for name in candidate_types if fnmatch.fnmatchcase(name, token)
            ]
            if not matches:
                continue
            for name in matches:
                if name not in seen:
                    seen.add(name)
                    selected.append(name)
            continue

        if token in SUPPORTED_ENTITY_TYPES:
            if token not in seen:
                seen.add(token)
                selected.append(token)

    return selected


@lru_cache(maxsize=16)
def _entity_handles_by_type_name(path: str, type_name: str) -> tuple[int, ...]:
    target = str(type_name).strip().upper()
    if not target:
        return ()
    try:
        rows = raw.list_object_headers_with_type(path)
    except Exception:
        return ()
    handles: list[int] = []
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 5:
            continue
        name = str(row[4]).strip().upper()
        if name != target:
            continue
        try:
            handles.append(int(row[0]))
        except Exception:
            continue
    return tuple(handles)


@lru_cache(maxsize=16)
def _object_headers_with_type_map(path: str) -> dict[int, tuple[int, int, int, str, str]]:
    try:
        rows = raw.list_object_headers_with_type(path)
    except Exception:
        return {}

    out: dict[int, tuple[int, int, int, str, str]] = {}
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 6:
            continue
        try:
            handle = int(row[0])
            offset = int(row[1])
            data_size = int(row[2])
            type_code = int(row[3])
        except Exception:
            continue
        type_name = str(row[4]).strip().upper()
        type_class = str(row[5]).strip().upper()
        out[handle] = (offset, data_size, type_code, type_name, type_class)
    return out


def _extract_ascii_preview(raw_bytes: bytes) -> str | None:
    if not raw_bytes:
        return None
    best: str | None = None
    for match in re.finditer(rb"[ -~]{6,}", raw_bytes):
        text = match.group(0).decode("ascii", errors="ignore").strip()
        if not text:
            continue
        if best is None or len(text) > len(best):
            best = text
    if best is None:
        return None
    if len(best) > 96:
        return f"{best[:93]}..."
    return best


def _synthetic_embedded_text_handle(source_handle: int, index: int, salt: int) -> int:
    return ((int(source_handle) + 1) << 32) | ((int(salt) & 0xFF) << 24) | (int(index) & 0xFFFFFF)


@lru_cache(maxsize=16)
def _layer_names_by_handle(path: str) -> dict[int, str]:
    try:
        return {
            int(handle): str(name)
            for handle, name in raw.decode_layer_names(path)
            if isinstance(handle, int) and isinstance(name, str)
        }
    except Exception:
        return {}


def _is_plausible_layer_name_for_recovered_text(name: str | None) -> bool:
    if not isinstance(name, str):
        return False
    value = name.strip()
    if not value:
        return False
    invalid = set('<>/\\":;?*|=')
    return not any(ch in invalid or ord(ch) < 32 for ch in value)


def _infer_adjacent_recovered_text_layer_handle(
    path: str,
    source_layer_handle: int | None,
    recovery_mode: str | None,
) -> int | None:
    if source_layer_handle is None or recovery_mode not in {
        "marker",
        "direct_attdef",
        "direct_custom_text",
        "short_direct_custom_text",
    }:
        return None
    layer_names = _layer_names_by_handle(path)
    source_name = layer_names.get(int(source_layer_handle))
    if _is_plausible_layer_name_for_recovered_text(source_name):
        return None

    prefer_text = recovery_mode == "marker"
    by_name = {name: handle for handle, name in layer_names.items()}
    best: tuple[int, int, int] | None = None
    for text_handle, text_name in layer_names.items():
        normalized = text_name.strip()
        if not _is_plausible_layer_name_for_recovered_text(normalized):
            continue
        if not normalized.upper().endswith("_TEXT"):
            continue
        base_name = normalized[:-5]
        base_handle = by_name.get(base_name)
        if base_handle is None:
            continue
        if not _is_plausible_layer_name_for_recovered_text(layer_names.get(base_handle)):
            continue
        if max(abs(text_handle - int(source_layer_handle)), abs(base_handle - int(source_layer_handle))) > 8:
            continue
        score = abs(base_handle - int(source_layer_handle)) + abs(text_handle - int(source_layer_handle))
        candidate = (score, min(base_handle, text_handle), text_handle if prefer_text else base_handle)
        if best is None or candidate < best:
            best = candidate
    if best is None:
        return None
    return best[2]


_MODELSPACE_BLOCK_NAMES = {"*MODEL_SPACE", "*MODEL SPACE", "MODELSPACE"}


@lru_cache(maxsize=16)
def _entity_placement_map(path: str) -> dict[int, tuple[int, int]]:
    """handle -> (entmode, owner_handle or 0) for every entity, from the common header."""
    decode = getattr(raw, "decode_entity_placements", None)
    if not callable(decode):
        return {}
    try:
        rows = decode(path)
    except Exception:
        return {}
    placements: dict[int, tuple[int, int]] = {}
    for row in rows:
        try:
            handle, mode, owner = int(row[0]), int(row[1]), int(row[2])
        except Exception:
            continue
        placements[handle] = (mode, owner)
    return placements


@lru_cache(maxsize=16)
def _modelspace_block_handles(path: str) -> tuple[int, ...]:
    block_name_map, _ = _block_and_endblk_name_maps(path)
    return tuple(
        sorted(
            int(handle)
            for handle, name in block_name_map.items()
            if isinstance(name, str) and name.strip().upper() in {"*MODEL_SPACE", "*MODEL SPACE", "MODELSPACE"}
        )
    )


@lru_cache(maxsize=16)
def _unknown_shifted_text_entities(
    path: str,
) -> tuple[
    tuple[int, str, tuple[float, float, float], float, float, int | None, int | None, str | None, str | None],
    ...,
]:
    modelspace_owner_handle = next(iter(_modelspace_block_handles(path)), None)
    try:
        rows = raw.decode_unknown_embedded_text_entities(
            path,
            modelspace_owner_handle=modelspace_owner_handle,
        )
    except Exception:
        return ()
    layer_handle_by_source: dict[int, int] = {}
    try:
        handles = [int(row[0]) for row in rows if isinstance(row, tuple) and len(row) >= 1]
        for source_handle, layer_handle in raw.decode_object_entity_layer_handles(path, handles):
            layer_handle_by_source[int(source_handle)] = int(layer_handle)
    except Exception:
        layer_handle_by_source = {}

    out = []
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 6:
            continue
        source_handle = int(row[0])
        out.append(
            (
                source_handle,
                row[1],
                row[2],
                row[3],
                row[4],
                row[5],
                layer_handle_by_source.get(source_handle),
                row[6] if len(row) >= 7 else None,
                row[7] if len(row) >= 8 else None,
            )
        )
    return tuple(out)


def _extract_likely_handle_refs(
    raw_bytes: bytes,
    known_handles: set[int],
    *,
    max_count: int = 8,
    min_handle: int = 64,
) -> list[int]:
    if not raw_bytes or not known_handles:
        return []
    found: list[int] = []
    seen: set[int] = set()

    def _push(value: int) -> None:
        if value < min_handle or value not in known_handles or value in seen:
            return
        seen.add(value)
        found.append(value)

    scan_len = min(len(raw_bytes), 512)
    for offset in range(0, max(0, scan_len - 4 + 1)):
        value = int.from_bytes(raw_bytes[offset : offset + 4], byteorder="little", signed=False)
        _push(value)
        if len(found) >= max_count:
            return found
    for offset in range(0, max(0, scan_len - 8 + 1)):
        value = int.from_bytes(raw_bytes[offset : offset + 8], byteorder="little", signed=False)
        _push(value)
        if len(found) >= max_count:
            return found
    return found


def _acis_role_hint(
    type_code: int,
    record_size: int | None,
    ascii_preview: str | None,
) -> str:
    hint = _ACIS_ROLE_HINTS.get(type_code)
    if hint is None:
        if 0x214 <= type_code <= 0x225:
            return "acis-aux"
        return "unknown"
    if hint == "acis-header" and ascii_preview:
        return "acis-text-header"
    if hint == "acis-payload-chunk" and isinstance(record_size, int) and record_size >= 128:
        return "acis-payload-main"
    return hint


def _handle_ref_details(
    handles: list[int],
    header_map: dict[int, tuple[int, int, int, str, str]],
) -> list[dict[str, object]]:
    details: list[dict[str, object]] = []
    for handle in handles:
        offset, data_size, type_code, type_name, type_class = header_map.get(
            handle,
            (0, 0, 0, "UNKNOWN", ""),
        )
        details.append(
            {
                "handle": handle,
                "offset": offset,
                "data_size": data_size,
                "type_code": type_code,
                "type_name": type_name,
                "type_class": type_class,
            }
        )
    return details


def _normalize_int_handles(values: object) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for item in list(values or []):
        try:
            value = int(item)
        except Exception:
            continue
        if value <= 0 or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _merge_handle_lists(primary: object, secondary: object) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for values in (primary, secondary):
        for item in list(values or []):
            try:
                value = int(item)
            except Exception:
                continue
            if value <= 0 or value in seen:
                continue
            seen.add(value)
            out.append(value)
    return out


def _select_acis_parent_ref_handles(
    stream_refs: list[int],
    scanned_refs: list[int],
    *,
    confidence: int,
) -> tuple[list[int], str]:
    if not stream_refs:
        return list(scanned_refs), "scan-only"

    scanned_set = set(scanned_refs)
    overlap_refs = [ref for ref in stream_refs if ref in scanned_set]

    if confidence >= 60:
        return list(stream_refs), "stream"

    if overlap_refs:
        if confidence >= 40:
            return list(overlap_refs), "stream-overlap"
        return list(overlap_refs), "stream-scan-overlap"

    if confidence >= 40:
        return list(stream_refs), "stream-mid"

    # Low-confidence decode with no corroborating overlap: keep only explicit
    # overlap and drop inferred references to avoid noisy edges.
    return [], "lowconf-drop"


def _build_acis_entity_payload(
    entity_handle: int,
    candidate_handles: list[int],
    acis_record_map: dict[int, dict[str, object]],
) -> dict[str, object]:
    candidate_handles = _normalize_int_handles(candidate_handles)
    candidate_index = {handle: index for index, handle in enumerate(candidate_handles)}
    candidate_set = set(candidate_handles)

    records: list[dict[str, object]] = []
    for index, handle in enumerate(candidate_handles):
        record = dict(acis_record_map.get(handle, {"handle": handle}))
        refs_source = record.get("acis_parent_ref_handles")
        refs = _normalize_int_handles(
            refs_source if refs_source is not None else record.get("likely_handle_refs")
        )
        parent_ref_strategy = str(record.get("acis_parent_ref_strategy") or "")
        if not refs and parent_ref_strategy == "lowconf-drop":
            # Entity-level safety net: if the merged candidates still include only
            # the current entity owner, recover that edge while keeping noisy refs dropped.
            likely_refs = _normalize_int_handles(record.get("likely_handle_refs"))
            if entity_handle in likely_refs:
                refs = [entity_handle]
                parent_ref_strategy = "lowconf-entity-fallback"
        record["acis_parent_ref_strategy_effective"] = parent_ref_strategy
        entity_refs = [ref for ref in refs if ref == entity_handle]
        candidate_refs = [ref for ref in refs if ref in candidate_set and ref != handle]
        external_refs = [ref for ref in refs if ref not in candidate_set and ref != entity_handle]

        record["acis_candidate_index"] = index
        record["entity_ref_handles"] = entity_refs
        record["candidate_ref_handles"] = candidate_refs
        record["external_ref_handles"] = external_refs
        records.append(record)

    role_by_handle: dict[int, str] = {}
    for record in records:
        try:
            handle = int(record.get("handle", 0))
        except Exception:
            continue
        role_by_handle[handle] = str(record.get("acis_role_hint") or "unknown")

    def _select_candidate_parent(
        current_index: int,
        candidate_refs: list[int],
        *,
        allowed_roles: set[str] | None = None,
    ) -> int | None:
        filtered = [
            ref
            for ref in candidate_refs
            if allowed_roles is None or role_by_handle.get(ref, "unknown") in allowed_roles
        ]
        if not filtered:
            return None
        prev_filtered = [ref for ref in filtered if candidate_index.get(ref, -1) < current_index]
        if prev_filtered:
            return max(prev_filtered, key=lambda ref: candidate_index.get(ref, -1))
        return filtered[0]

    for record in records:
        role_hint = str(record.get("acis_role_hint") or "unknown")
        current_index = int(record.get("acis_candidate_index", 0))
        entity_refs = _normalize_int_handles(record.get("entity_ref_handles"))
        candidate_refs = _normalize_int_handles(record.get("candidate_ref_handles"))
        external_refs = _normalize_int_handles(record.get("external_ref_handles"))

        parent_handle: int | None = None
        parent_kind = "none"
        parent_rule = "none"

        if role_hint in {"acis-header", "acis-text-header"}:
            if entity_refs:
                parent_handle = entity_refs[0]
                parent_kind = "entity"
                parent_rule = "header-prefers-entity"
            else:
                candidate_parent = _select_candidate_parent(
                    current_index,
                    candidate_refs,
                    allowed_roles={"acis-header", "acis-text-header"},
                )
                if candidate_parent is not None:
                    parent_handle = candidate_parent
                    parent_kind = "candidate"
                    parent_rule = "header-fallback-candidate"
        elif role_hint == "acis-link-table":
            for allowed_roles, rule in (
                ({"acis-header", "acis-text-header"}, "link-prefers-header"),
                (None, "link-fallback-candidate"),
            ):
                candidate_parent = _select_candidate_parent(
                    current_index,
                    candidate_refs,
                    allowed_roles=allowed_roles,
                )
                if candidate_parent is not None:
                    parent_handle = candidate_parent
                    parent_kind = "candidate"
                    parent_rule = rule
                    break
            if parent_handle is None and entity_refs:
                parent_handle = entity_refs[0]
                parent_kind = "entity"
                parent_rule = "link-fallback-entity"
        elif role_hint in {"acis-payload-main", "acis-payload-chunk"}:
            for allowed_roles, rule in (
                ({"acis-link-table"}, "payload-prefers-link"),
                ({"acis-payload-main", "acis-payload-chunk"}, "payload-prefers-payload"),
                ({"acis-header", "acis-text-header"}, "payload-fallback-header"),
                (None, "payload-fallback-candidate"),
            ):
                candidate_parent = _select_candidate_parent(
                    current_index,
                    candidate_refs,
                    allowed_roles=allowed_roles,
                )
                if candidate_parent is not None:
                    parent_handle = candidate_parent
                    parent_kind = "candidate"
                    parent_rule = rule
                    break
            if parent_handle is None and entity_refs:
                parent_handle = entity_refs[0]
                parent_kind = "entity"
                parent_rule = "payload-fallback-entity"
        else:
            if entity_refs:
                parent_handle = entity_refs[0]
                parent_kind = "entity"
                parent_rule = "generic-entity"
            else:
                candidate_parent = _select_candidate_parent(current_index, candidate_refs)
                if candidate_parent is not None:
                    parent_handle = candidate_parent
                    parent_kind = "candidate"
                    parent_rule = "generic-candidate"

        if parent_handle is None and external_refs:
            parent_handle = external_refs[0]
            parent_kind = "external"
            parent_rule = "external-fallback"

        record["acis_parent_handle"] = parent_handle
        record["acis_parent_kind"] = parent_kind
        record["acis_parent_rule"] = parent_rule

    child_map: dict[int, list[int]] = {}
    edges: list[dict[str, object]] = []
    primary_edges: list[dict[str, object]] = []
    for record in records:
        source = int(record.get("handle", 0))
        for target in list(record.get("entity_ref_handles") or []):
            edges.append({"source": source, "target": int(target), "kind": "entity"})
        for target in list(record.get("candidate_ref_handles") or []):
            target = int(target)
            edges.append({"source": source, "target": target, "kind": "candidate"})
        for target in list(record.get("external_ref_handles") or []):
            edges.append({"source": source, "target": int(target), "kind": "external"})
        parent_handle = record.get("acis_parent_handle")
        parent_kind = str(record.get("acis_parent_kind") or "none")
        if isinstance(parent_handle, int) and parent_kind in {"entity", "candidate", "external"}:
            primary_edges.append(
                {
                    "source": source,
                    "target": parent_handle,
                    "kind": parent_kind,
                    "rule": str(record.get("acis_parent_rule") or "none"),
                }
            )
        if record.get("acis_parent_kind") == "candidate":
            parent = record.get("acis_parent_handle")
            if isinstance(parent, int):
                child_map.setdefault(parent, []).append(source)

    for record in records:
        source = int(record.get("handle", 0))
        record["acis_child_candidate_handles"] = child_map.get(source, [])

    return {
        "acis_candidate_handles": candidate_handles,
        "acis_candidate_records": records,
        "acis_candidate_edges": edges,
        "acis_primary_edges": primary_edges,
    }


@lru_cache(maxsize=16)
def _acis_candidate_handles_map(path: str) -> dict[int, tuple[int, ...]]:
    try:
        rows = raw.list_object_headers_with_type(path)
    except Exception:
        return {}

    normalized_rows: list[tuple[int, int, int, str, str]] = []
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 6:
            continue
        try:
            handle = int(row[0])
            offset = int(row[1])
            type_code = int(row[3])
        except Exception:
            continue
        type_name = str(row[4]).strip().upper()
        type_class = str(row[5]).strip().upper()
        normalized_rows.append((handle, offset, type_code, type_name, type_class))

    if not normalized_rows:
        return {}

    def _scan_candidates(
        sorted_rows: list[tuple[int, int, int, str, str]],
    ) -> dict[int, tuple[int, ...]]:
        target_types = {"3DSOLID", "BODY", "REGION"}
        out: dict[int, tuple[int, ...]] = {}
        for index, (handle, _offset, _type_code, type_name, type_class) in enumerate(sorted_rows):
            if type_class not in {"E", "ENTITY"} or type_name not in target_types:
                continue
            candidates: list[int] = []
            for (
                next_handle,
                _next_offset,
                next_type_code,
                next_type_name,
                next_type_class,
            ) in sorted_rows[index + 1 :]:
                if next_type_class in {"E", "ENTITY"}:
                    break
                if not next_type_name.startswith("UNKNOWN("):
                    continue
                # ACIS companion records for modeler entities are typically in the
                # dynamic UNKNOWN range 0x214-0x225 for our current sample corpus.
                if 0x214 <= next_type_code <= 0x225:
                    candidates.append(next_handle)
            out[handle] = tuple(candidates)
        return out

    by_offset = sorted(normalized_rows, key=lambda item: (item[1], item[0]))
    by_handle = sorted(normalized_rows, key=lambda item: (item[0], item[1]))
    offset_map = _scan_candidates(by_offset)
    handle_map = _scan_candidates(by_handle)

    out: dict[int, tuple[int, ...]] = {}
    for handle in set(offset_map.keys()) | set(handle_map.keys()):
        handle_candidates = handle_map.get(handle, ())
        offset_candidates = offset_map.get(handle, ())
        if handle_candidates:
            out[handle] = handle_candidates
        elif offset_candidates:
            out[handle] = offset_candidates
        else:
            out[handle] = ()

    return out


@lru_cache(maxsize=16)
def _long_transaction_record_map(path: str) -> dict[int, dict[str, object]]:
    return _entity_record_diagnostics_map(path, "LONG_TRANSACTION")


@lru_cache(maxsize=16)
def _oleframe_record_map(path: str) -> dict[int, dict[str, object]]:
    return _entity_record_diagnostics_map(path, "OLEFRAME")


@lru_cache(maxsize=16)
def _ole2frame_record_map(path: str) -> dict[int, dict[str, object]]:
    return _entity_record_diagnostics_map(path, "OLE2FRAME")


def _entity_record_diagnostics_map(
    path: str,
    type_name: str,
) -> dict[int, dict[str, object]]:
    entity_handles = list(_entity_handles_by_type_name(path, type_name))
    if not entity_handles:
        return {}

    try:
        rows = raw.read_object_records_by_handle(path, entity_handles)
    except Exception:
        rows = []

    header_map = _object_headers_with_type_map(path)
    known_handles = set(header_map.keys())
    out: dict[int, dict[str, object]] = {}
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 5:
            continue
        try:
            handle = int(row[0])
            offset = int(row[1])
            data_size = int(row[2])
            type_code = int(row[3])
        except Exception:
            continue
        record_bytes = bytes(row[4]) if row[4] is not None else b""
        likely_handle_refs = [
            ref
            for ref in _extract_likely_handle_refs(record_bytes, known_handles)
            if ref != handle
        ]
        out[handle] = {
            "record_offset": offset,
            "record_data_size": data_size,
            "record_type_code": type_code,
            "record_size": len(record_bytes),
            "ascii_preview": _extract_ascii_preview(record_bytes),
            "likely_handle_refs": likely_handle_refs,
            "likely_handle_ref_details": _handle_ref_details(likely_handle_refs, header_map),
        }

    for handle in entity_handles:
        if handle in out:
            continue
        offset, data_size, type_code, _type_name, _type_class = header_map.get(
            handle,
            (0, 0, 0, "UNKNOWN", ""),
        )
        out[handle] = {
            "record_offset": offset,
            "record_data_size": data_size,
            "record_type_code": type_code,
            "record_size": None,
            "ascii_preview": None,
            "likely_handle_refs": [],
            "likely_handle_ref_details": [],
        }

    return out


@lru_cache(maxsize=16)
def _acis_candidate_record_map(path: str) -> dict[int, dict[str, object]]:
    candidate_map = _acis_candidate_handles_map(path)
    candidate_handles = sorted(
        {
            handle
            for handles in candidate_map.values()
            for handle in handles
            if isinstance(handle, int) and handle > 0
        }
    )
    if not candidate_handles:
        return {}

    try:
        rows = raw.read_object_records_by_handle(path, candidate_handles)
    except Exception:
        rows = []
    try:
        acis_info_rows = raw.decode_acis_candidate_infos(path, candidate_handles)
    except Exception:
        acis_info_rows = []
    acis_info_map: dict[int, tuple[int, int, str, list[int], int]] = {}
    for row in acis_info_rows:
        if not isinstance(row, tuple) or len(row) < 5:
            continue
        try:
            handle = int(row[0])
            type_code = int(row[1])
            data_size = int(row[2])
        except Exception:
            continue
        role_hint = str(row[3]).strip()
        refs = _normalize_int_handles(row[4])
        confidence = 0
        if len(row) >= 6:
            try:
                confidence = int(row[5])
            except Exception:
                confidence = 0
        confidence = max(0, min(100, confidence))
        acis_info_map[handle] = (type_code, data_size, role_hint, refs, confidence)

    header_map = _object_headers_with_type_map(path)
    known_handles = set(header_map.keys())
    out: dict[int, dict[str, object]] = {}
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 5:
            continue
        try:
            handle = int(row[0])
            offset = int(row[1])
            data_size = int(row[2])
            type_code = int(row[3])
        except Exception:
            continue
        record_bytes = bytes(row[4]) if row[4] is not None else b""
        _, _, _, type_name, _type_class = header_map.get(
            handle,
            (offset, data_size, type_code, f"UNKNOWN(0x{type_code:X})", ""),
        )
        info = acis_info_map.get(handle)
        if info is not None:
            info_type_code, info_data_size, info_role_hint, info_refs, info_confidence = info
            if info_type_code > 0:
                type_code = info_type_code
            if info_data_size > 0:
                data_size = info_data_size
            role_hint = info_role_hint
            ref_confidence = info_confidence
            stream_handle_refs = [
                ref for ref in info_refs if ref in known_handles and ref != handle
            ]
        else:
            role_hint = ""
            ref_confidence = 0
            stream_handle_refs = []
        scanned_refs = [
            ref
            for ref in _extract_likely_handle_refs(record_bytes, known_handles)
            if ref != handle
        ]
        if stream_handle_refs:
            if ref_confidence < 40:
                likely_handle_refs = _merge_handle_lists(stream_handle_refs, scanned_refs)
            else:
                likely_handle_refs = list(stream_handle_refs)
            parent_handle_refs, parent_ref_strategy = _select_acis_parent_ref_handles(
                stream_handle_refs,
                scanned_refs,
                confidence=ref_confidence,
            )
        else:
            likely_handle_refs = scanned_refs
            parent_handle_refs, parent_ref_strategy = _select_acis_parent_ref_handles(
                stream_handle_refs,
                scanned_refs,
                confidence=ref_confidence,
            )
        ascii_preview = _extract_ascii_preview(record_bytes)
        out[handle] = {
            "handle": handle,
            "offset": offset,
            "data_size": data_size,
            "type_code": type_code,
            "type_name": type_name,
            "record_size": len(record_bytes),
            "ascii_preview": ascii_preview,
            "likely_handle_refs": likely_handle_refs,
            "likely_handle_ref_details": _handle_ref_details(likely_handle_refs, header_map),
            "acis_stream_handle_refs": stream_handle_refs,
            "acis_scanned_handle_refs": scanned_refs,
            "acis_parent_ref_handles": parent_handle_refs,
            "acis_parent_ref_strategy": parent_ref_strategy,
            "acis_ref_confidence": ref_confidence,
            "acis_role_hint": role_hint
            if role_hint
            else _acis_role_hint(type_code, len(record_bytes), ascii_preview),
        }

    for handle in candidate_handles:
        if handle in out:
            continue
        offset, data_size, type_code, type_name, _type_class = header_map.get(
            handle,
            (0, 0, 0, "UNKNOWN", ""),
        )
        out[handle] = {
            "handle": handle,
            "offset": offset,
            "data_size": data_size,
            "type_code": type_code,
            "type_name": type_name,
            "record_size": None,
            "ascii_preview": None,
            "likely_handle_refs": [],
            "likely_handle_ref_details": [],
            "acis_stream_handle_refs": [],
            "acis_scanned_handle_refs": [],
            "acis_parent_ref_handles": [],
            "acis_parent_ref_strategy": "none",
            "acis_ref_confidence": 0,
            "acis_role_hint": (
                acis_info_map.get(handle, (type_code, data_size, "", [], 0))[2]
                or _acis_role_hint(type_code, None, None)
            ),
        }

    return out


@lru_cache(maxsize=16)
def _polyline_sequence_relationships(
    path: str,
) -> tuple[
    dict[int, dict[str, object]],
    dict[int, tuple[int, str]],
    dict[int, tuple[int, str]],
]:
    try:
        rows = raw.decode_polyline_sequence_members(path)
    except Exception:
        return {}, {}, {}

    polyline_map: dict[int, dict[str, object]] = {}
    vertex_owner_map: dict[int, tuple[int, str]] = {}
    seqend_owner_map: dict[int, tuple[int, str]] = {}

    for row in rows:
        if not isinstance(row, tuple) or len(row) < 5:
            continue
        raw_handle, raw_type_name, raw_vertex_handles, raw_face_handles, raw_seqend_handle = row
        try:
            handle = int(raw_handle)
        except Exception:
            continue
        owner_type = str(raw_type_name).strip().upper()
        if owner_type == "":
            continue

        vertex_handles: list[int] = []
        for item in list(raw_vertex_handles or []):
            try:
                vertex_handles.append(int(item))
            except Exception:
                continue
        face_handles: list[int] = []
        for item in list(raw_face_handles or []):
            try:
                face_handles.append(int(item))
            except Exception:
                continue
        seqend_handle: int | None = None
        if raw_seqend_handle is not None:
            try:
                seqend_handle = int(raw_seqend_handle)
            except Exception:
                seqend_handle = None

        polyline_map[handle] = {
            "vertex_handles": tuple(vertex_handles),
            "face_handles": tuple(face_handles),
            "seqend_handle": seqend_handle,
        }
        for vertex_handle in vertex_handles:
            vertex_owner_map[vertex_handle] = (handle, owner_type)
        for face_handle in face_handles:
            vertex_owner_map[face_handle] = (handle, owner_type)
        if seqend_handle is not None:
            seqend_owner_map[seqend_handle] = (handle, owner_type)

    return polyline_map, vertex_owner_map, seqend_owner_map


@lru_cache(maxsize=16)
def _block_and_endblk_name_maps(path: str) -> tuple[dict[int, str], dict[int, str]]:
    block_handles = list(_entity_handles_by_type_name(path, "BLOCK"))
    endblk_handles = list(_entity_handles_by_type_name(path, "ENDBLK"))
    if not block_handles and not endblk_handles:
        return {}, {}

    # Preferred: Rust-side deterministic mapping from BLOCK_HEADER -> BLOCK/ENDBLK.
    try:
        entity_rows = raw.decode_block_entity_names(path)
    except Exception:
        entity_rows = []
    if entity_rows:
        block_map: dict[int, str] = {}
        endblk_map: dict[int, str] = {}
        for row in entity_rows:
            if not isinstance(row, tuple) or len(row) < 3:
                continue
            handle, type_name, name = row[0], row[1], row[2]
            if not isinstance(name, str) or not name:
                continue
            try:
                handle_key = int(handle)
            except Exception:
                continue
            type_token = str(type_name).strip().upper()
            if type_token == "BLOCK":
                block_map[handle_key] = name
            elif type_token == "ENDBLK":
                endblk_map[handle_key] = name
        if block_map or endblk_map:
            return block_map, endblk_map

    rows = _block_header_name_rows(path)

    by_header_handle: dict[int, str] = {}
    ordered_names: list[str] = []
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 2:
            continue
        header_handle, name = row[0], row[1]
        if not isinstance(name, str) or not name:
            continue
        ordered_names.append(name)
        try:
            by_header_handle[int(header_handle)] = name
        except Exception:
            pass

    block_map: dict[int, str] = {}
    endblk_map: dict[int, str] = {}

    # Prefer exact handle matches when available.
    for handle in block_handles:
        name = by_header_handle.get(handle)
        if name:
            block_map[handle] = name
    for handle in endblk_handles:
        name = by_header_handle.get(handle)
        if name:
            endblk_map[handle] = name

    # Fallback: assign names in declaration order to preserve deterministic output.
    remaining_names = iter(ordered_names)
    for handle in block_handles:
        if handle not in block_map:
            name = next(remaining_names, None)
            if isinstance(name, str):
                block_map[handle] = name
    for index, handle in enumerate(endblk_handles):
        if handle in endblk_map:
            continue
        if index < len(block_handles):
            paired_name = block_map.get(block_handles[index])
            if paired_name:
                endblk_map[handle] = paired_name
                continue
        name = next(remaining_names, None)
        if isinstance(name, str):
            endblk_map[handle] = name

    return block_map, endblk_map


@lru_cache(maxsize=16)
def _block_header_name_map(path: str) -> dict[int, str]:
    valid_handles = set(_entity_handles_by_type_name(path, "BLOCK_HEADER"))
    rows = _block_header_name_rows(path)
    mapping: dict[int, str] = {}
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 2:
            continue
        raw_handle, raw_name = row[0], row[1]
        if not isinstance(raw_name, str):
            continue
        name = raw_name.strip()
        if not name:
            continue
        try:
            handle = int(raw_handle)
        except Exception:
            continue
        if valid_handles and handle not in valid_handles:
            continue
        mapping[handle] = name
    return mapping


@lru_cache(maxsize=16)
def _block_text_height_map(path: str) -> dict[int, float]:
    """Resolve unambiguous saved TEXT/MTEXT heights by their owner block.

    A dimension's anonymous block contains its saved display, including style
    overrides. Do not choose an arbitrary height for blocks with mixed sizes.
    """
    heights: dict[int, float] = {}
    ambiguous: set[int] = set()
    for decode, height_from_row, owner_index in (
        (raw.decode_text_entities, lambda row: row[5][2], 8),
        (raw.decode_mtext_entities, lambda row: row[6], 10),
    ):
        try:
            rows = decode(path)
        except Exception:
            continue
        for row in rows:
            try:
                if not row[1].strip():
                    continue
                owner = int(row[owner_index])
                height = float(height_from_row(row))
            except (IndexError, TypeError, ValueError, AttributeError):
                continue
            if owner <= 0:
                continue
            if not math.isfinite(height) or height <= 0:
                ambiguous.add(owner)
            elif owner in heights and not math.isclose(heights[owner], height, rel_tol=1e-9):
                ambiguous.add(owner)
            else:
                heights[owner] = height
    return {owner: height for owner, height in heights.items() if owner not in ambiguous}


@lru_cache(maxsize=16)
def _block_header_name_rows(path: str) -> list[tuple]:
    try:
        return list(raw.decode_block_header_names(path))
    except Exception:
        return []


@lru_cache(maxsize=16)
def _line_arc_circle_rows(
    path: str,
) -> tuple[
    list[tuple[int, float, float, float, float, float, float]],
    list[tuple[int, float, float, float, float, float, float]],
    list[tuple[int, float, float, float, float]],
]:
    try:
        line_rows, arc_rows, circle_rows = raw.decode_line_arc_circle_entities(path)
        line_rows_list = list(line_rows)
        if not _has_implausible_line_rows(line_rows_list):
            return line_rows_list, list(arc_rows), list(circle_rows)
    except Exception:
        pass
    return (
        list(raw.decode_line_entities(path)),
        list(raw.decode_arc_entities(path)),
        list(raw.decode_circle_entities(path)),
    )


def _has_implausible_line_rows(
    line_rows: list[tuple[int, float, float, float, float, float, float]],
) -> bool:
    for row in line_rows:
        if not isinstance(row, tuple) or len(row) < 7:
            continue
        _, sx, sy, sz, ex, ey, ez = row
        values = (sx, sy, sz, ex, ey, ez)
        if any(not math.isfinite(value) for value in values):
            return True
        if max(abs(value) for value in values) > 1.0e8:
            return True
    return False


def _insert_minsert_rows(
    path: str,
) -> tuple[list[tuple], list[tuple]]:
    decode_both = getattr(raw, "decode_insert_minsert_entities", None)
    if callable(decode_both):
        try:
            insert_rows, minsert_rows = decode_both(path)
            return list(insert_rows), list(minsert_rows)
        except Exception:
            pass
    return list(raw.decode_insert_entities(path)), list(raw.decode_minsert_entities(path))


@lru_cache(maxsize=16)
def _insert_owner_handle_map(path: str) -> dict[int, int | None]:
    decode_owner_handles = getattr(raw, "decode_insert_owner_handles", None)
    return _decode_owner_handle_map(path, decode_owner_handles)


def _decode_owner_handle_map(
    path: str,
    decode_owner_handles: Any,
) -> dict[int, int | None]:
    if not callable(decode_owner_handles):
        return {}
    try:
        rows = decode_owner_handles(path)
    except Exception:
        return {}
    result: dict[int, int | None] = {}
    for row in rows:
        if not isinstance(row, tuple) or len(row) < 2:
            continue
        raw_handle, raw_owner_handle = row[0], row[1]
        try:
            handle = int(raw_handle)
        except Exception:
            continue
        owner_handle = None
        if raw_owner_handle is not None:
            try:
                owner_handle = int(raw_owner_handle)
            except Exception:
                owner_handle = None
        result[handle] = owner_handle
    return result


@lru_cache(maxsize=16)
def _line_owner_handle_map(path: str) -> dict[int, int | None]:
    return _decode_owner_handle_map(path, getattr(raw, "decode_line_owner_handles", None))


@lru_cache(maxsize=16)
def _arc_owner_handle_map(path: str) -> dict[int, int | None]:
    return _decode_owner_handle_map(path, getattr(raw, "decode_arc_owner_handles", None))


@lru_cache(maxsize=16)
def _circle_owner_handle_map(path: str) -> dict[int, int | None]:
    return _decode_owner_handle_map(path, getattr(raw, "decode_circle_owner_handles", None))


@lru_cache(maxsize=16)
def _point_owner_handle_map(path: str) -> dict[int, int | None]:
    return _decode_owner_handle_map(path, getattr(raw, "decode_point_owner_handles", None))


@lru_cache(maxsize=16)
def _lwpolyline_owner_handle_map(path: str) -> dict[int, int | None]:
    return _decode_owner_handle_map(path, getattr(raw, "decode_lwpolyline_owner_handles", None))


class _EntityStyleMap(dict):
    """``handle -> (color index, true color, layer handle)``.

    Two more maps ride along so that every entity gets them where it gets its color:

    - ``linetypes``: ``handle -> (linetype name, linetype handle, linetype scale)``
    - ``common_layers``: ``handle -> layer handle`` read from the common entity data,
      which holds for every entity type. It takes precedence over the layer handle
      of the type-specific decoders.
    - ``lineweights``: ``handle -> (lineweight, invisible)``
    """

    linetypes: dict[int, tuple[str | None, int | None, float]]
    common_layers: dict[int, int]
    lineweights: dict[int, tuple[int | None, bool]]


@lru_cache(maxsize=16)
def _entity_style_map(path: str) -> dict[int, tuple[int | None, int | None, int]]:
    styles = _EntityStyleMap()
    styles.write_geometry = {}
    styles.mtext_write_properties = {}
    try:
        styles.write_geometry = {h: (thickness, extrusion, elevation) for h, thickness, extrusion, elevation in raw.decode_write_geometry(path)}
    except Exception:
        pass
    try:
        styles.mtext_write_properties = {h: (style, spacing, factor) for h, style, spacing, factor in raw.decode_mtext_write_properties(path)}
    except Exception:
        pass
    styles.linetypes = _entity_linetype_map(path)
    styles.common_layers = _entity_common_layer_map(path)
    styles.lineweights = _entity_lineweight_map(path)
    try:
        styles.update(
            (handle, (index, true_color, layer_handle))
            for handle, index, true_color, layer_handle in raw.decode_entity_styles(path)
        )
    except Exception:
        pass
    return styles


@lru_cache(maxsize=16)
def _linetype_rows(path: str) -> tuple[tuple[int, str, str, float, tuple[float, ...]], ...]:
    try:
        return tuple(
            (int(handle), str(name), str(description), float(length), tuple(dashes))
            for handle, name, description, length, dashes in raw.decode_linetypes(path)
        )
    except Exception:
        return ()


@lru_cache(maxsize=16)
def _linetype_tables(path: str) -> tuple[dict[int, str], dict[int, int]]:
    """``(linetype name by handle, linetype handle by layer handle)``."""
    names = {handle: name for handle, name, *_ in _linetype_rows(path)}
    try:
        layer_linetypes = {
            int(layer): int(linetype) for layer, linetype in raw.decode_layer_linetypes(path)
        }
    except Exception:
        layer_linetypes = {}
    return names, layer_linetypes


_LINETYPE_FLAG_NAMES = {0: "BYLAYER", 1: "BYBLOCK", 2: "CONTINUOUS"}


@lru_cache(maxsize=16)
def _entity_linetype_map(path: str) -> dict[int, tuple[str | None, int | None, float]]:
    """Linetype of every entity as DXF group 6 would name it, with its scale (group 48).

    ``BYLAYER``, ``BYBLOCK`` and ``CONTINUOUS`` are reported in upper case whether the
    entity stores them as a flag or as a handle to the built-in table entry. The
    name is ``None`` when the entity points to a linetype that cannot be read.
    """
    names, _layer_linetypes = _linetype_tables(path)
    try:
        rows = raw.decode_entity_linetypes(path)
    except Exception:
        return {}
    result: dict[int, tuple[str | None, int | None, float]] = {}
    for handle, _layer_handle, flags, linetype_handle, scale in rows:
        name = _LINETYPE_FLAG_NAMES.get(flags)
        if name is None:
            name = names.get(linetype_handle)
            if name is not None and name.upper() in ("BYLAYER", "BYBLOCK", "CONTINUOUS"):
                name = name.upper()
        result[handle] = (name, linetype_handle, scale)
    return result


@lru_cache(maxsize=16)
def _entity_common_layer_map(path: str) -> dict[int, int]:
    """Layer handle of every entity whose common entity data names a known layer."""
    layer_handles = set(_layer_names_by_handle(path))
    if not layer_handles:
        return {}
    try:
        rows = raw.decode_entity_linetypes(path)
    except Exception:
        return {}
    return {
        handle: layer_handle
        for handle, layer_handle, *_rest in rows
        if layer_handle in layer_handles
    }


@lru_cache(maxsize=16)
def _entity_lineweight_map(path: str) -> dict[int, tuple[int | None, bool]]:
    """``(lineweight, invisible)`` of every entity, as DXF groups 370 and 60 hold them."""
    decode = getattr(raw, "decode_entity_lineweights", None)
    if not callable(decode):
        return {}
    try:
        rows = decode(path)
    except Exception:
        return {}
    return {
        int(handle): (None if lineweight is None else int(lineweight), bool(invisible))
        for handle, lineweight, invisible in rows
    }


@lru_cache(maxsize=16)
def _dimstyle_map(path: str) -> dict[int, dict[str, Any]]:
    """``name``, ``dimscale``, ``dimasz`` and ``dimtxt`` of every dimension style."""
    decode = getattr(raw, "decode_dimstyles", None)
    if not callable(decode):
        return {}
    try:
        rows = decode(path)
    except Exception:
        return {}
    return {
        int(handle): {
            "name": str(name),
            "dimscale": float(dimscale),
            "dimasz": float(dimasz),
            "dimtxt": float(dimtxt),
        }
        for handle, name, dimscale, dimasz, dimtxt in rows
    }


def _viewport_rows(path: str) -> list[Any]:
    """Viewport rows with geometry when the extension provides them."""
    decode = getattr(raw, "decode_viewport_details", None)
    if callable(decode):
        try:
            return list(decode(path))
        except Exception:
            # Fall back to the handles; that call reports what is wrong with the file.
            pass
    return list(raw.decode_viewport_entities(path))


def _viewport_dxf(row: Any, layer_names: dict[int, str] | None) -> tuple[int, dict] | None:
    """DXF-style attributes of a paper-space viewport.

    ``center``, ``width`` and ``height`` place the viewport on the sheet.
    ``view_center`` (display coordinates), ``view_height``, ``view_target``,
    ``view_direction`` and ``view_twist_angle`` (degrees) describe what it
    shows; they are missing for R13/R14 files. ``frozen_layers`` names the
    layers that are frozen in this viewport and ``frozen_layer_handles`` holds
    their handles.
    """
    if not row:
        return None
    handle = int(row[0])
    if len(row) < 8:
        return handle, {}
    _, center, width, height, view, frozen_layer_handles, clip_boundary_handle, _layer = row[:8]
    dxf: dict[str, Any] = {}
    if center is not None:
        dxf["center"] = tuple(center)
        dxf["width"] = float(width)
        dxf["height"] = float(height)
    if view is not None:
        (
            target,
            direction,
            twist_angle,
            view_height,
            lens_length,
            front_clip_z,
            back_clip_z,
            view_center,
            status_flags,
            render_mode,
        ) = view
        dxf.update(
            {
                "view_target": tuple(target),
                "view_direction": tuple(direction),
                "view_twist_angle": math.degrees(twist_angle),
                "view_height": float(view_height),
                "view_center": tuple(view_center),
                "lens_length": float(lens_length),
                "front_clip_z": float(front_clip_z),
                "back_clip_z": float(back_clip_z),
                "status_flags": int(status_flags),
                "render_mode": int(render_mode),
            }
        )
    names = layer_names or {}
    dxf["frozen_layer_handles"] = [int(layer_handle) for layer_handle in frozen_layer_handles]
    dxf["frozen_layers"] = [
        names.get(layer_handle) or f"LAYER_{layer_handle:X}"
        for layer_handle in dxf["frozen_layer_handles"]
    ]
    if clip_boundary_handle:
        dxf["clip_boundary_handle"] = int(clip_boundary_handle)
    return handle, dxf


@lru_cache(maxsize=16)
def _layout_map(path: str) -> dict[int, dict[str, Any]]:
    """Layout objects by handle, with the model tab and the active sheet marked."""
    decode = getattr(raw, "decode_layout_objects", None)
    if not callable(decode):
        return {}
    try:
        rows = decode(path)
    except Exception:
        return {}
    header_names = _block_header_name_map(path)
    layouts: dict[int, dict[str, Any]] = {}
    for (
        handle,
        name,
        tab_order,
        flags,
        block_record_handle,
        paper,
        limits,
        extents,
        viewport_handles,
        last_active_viewport,
        plot,
    ) in rows:
        paper_width, paper_height, margins, paper_size, paper_units, plot_rotation = paper
        block_name = header_names.get(int(block_record_handle), "")
        layouts[int(handle)] = {
            "name": str(name),
            "tab_order": int(tab_order),
            "flags": int(flags),
            "model": block_name.strip().upper() in _MODELSPACE_BLOCK_NAMES,
            "active": False,
            "block_record_handle": int(block_record_handle),
            "paper_width": float(paper_width),
            "paper_height": float(paper_height),
            "margins": tuple(float(value) for value in margins),
            "paper_size": str(paper_size),
            "paper_units": int(paper_units),
            "plot_rotation": int(plot_rotation),
            "limmin": tuple(limits[0]),
            "limmax": tuple(limits[1]),
            "extmin": tuple(extents[0]),
            "extmax": tuple(extents[1]),
            "viewport_handles": [int(value) for value in viewport_handles],
            "last_active_viewport_handle": int(last_active_viewport),
            "plot_layout_flags": int(plot[0]),
            "plot_type": int(plot[2]),
            "plot_scale": (float(plot[5]), float(plot[6])),
        }
    active = _active_layout_handle(layouts, _entity_placement_map(path))
    if active is not None:
        layouts[active]["active"] = True
    return layouts


def _active_layout_handle(
    layouts: dict[int, dict[str, Any]], placements: dict[int, tuple[int, int]]
) -> int | None:
    """The paper-space layout whose entities are stored without an owner handle.

    The entities of the sheet that was current at save time carry
    ``entmode == 1``; those of every other sheet name their block record. So
    the active sheet is the one whose viewports are stored that way or, when
    it has no viewport, the only sheet whose block record owns no entity.
    """
    sheets = {handle: entry for handle, entry in layouts.items() if not entry["model"]}
    if not sheets:
        return None
    if len(sheets) == 1:
        return next(iter(sheets))
    for handle, entry in sorted(sheets.items(), key=lambda item: item[1]["tab_order"]):
        viewports = [*entry["viewport_handles"], entry["last_active_viewport_handle"]]
        if any(placements.get(viewport, (None, 0))[0] == 1 for viewport in viewports if viewport):
            return handle
    owners = {owner for mode, owner in placements.values() if mode == 0 and owner}
    unowned = [
        handle
        for handle, entry in sorted(sheets.items(), key=lambda item: item[1]["tab_order"])
        if entry["block_record_handle"] not in owners
    ]
    if len(unowned) == 1:
        return unowned[0]
    return None


def _tolerance_text_height(stored: float, dimstyle: dict[str, Any] | None) -> float:
    """Text height of a feature control frame.

    Only R13/R14 can store it with the entity. Otherwise it is the text height
    of the dimension style times its overall scale (a scale of 0 counts as 1).
    0.0 when neither is known.
    """
    if stored > 0.0:
        return stored
    if not dimstyle:
        return 0.0
    return dimstyle["dimtxt"] * (dimstyle["dimscale"] or 1.0)


@lru_cache(maxsize=16)
def _layer_state_map(path: str) -> dict[int, dict[str, Any]]:
    """``frozen``, ``off``, ``locked``, ``plot`` and ``lineweight`` of every layer."""
    decode = getattr(raw, "decode_layer_states", None)
    if not callable(decode):
        return {}
    try:
        rows = decode(path)
    except Exception:
        return {}
    return {
        int(handle): {
            "frozen": bool(frozen),
            "off": bool(off),
            "locked": bool(locked),
            "plot": bool(plot),
            "lineweight": int(lineweight),
        }
        for handle, frozen, off, _frozen_new, locked, plot, lineweight in rows
    }


@lru_cache(maxsize=16)
def _hatch_pattern_map(path: str) -> dict[int, dict[str, Any]]:
    """Pattern definition of every pattern-filled hatch (angles in degrees)."""
    try:
        rows = raw.decode_hatch_patterns(path)
    except Exception:
        return {}
    return {
        handle: {
            "pattern_angle": math.degrees(angle),
            "pattern_scale": scale,
            "pattern_double": bool(double),
            "pattern_lines": [
                {
                    "angle": math.degrees(line_angle),
                    "base": tuple(base),
                    "offset": tuple(offset),
                    "dashes": list(dashes),
                }
                for line_angle, base, offset, dashes in lines
            ],
        }
        for handle, angle, scale, double, lines in rows
    }


@lru_cache(maxsize=16)
def _layer_color_map(path: str) -> dict[int, tuple[int, int | None]]:
    try:
        return {
            handle: (index, true_color)
            for handle, index, true_color in raw.decode_layer_colors(path)
        }
    except Exception:
        return {}


def _layer_color_overrides(
    version: str,
    entity_style_map: dict[int, tuple[int | None, int | None, int]],
    layer_color_map: dict[int, tuple[int, int | None]],
) -> dict[int, tuple[int, int | None]]:
    if version not in {"AC1024", "AC1027", "AC1032"}:
        return {}

    usage: dict[int, int] = {}
    for _, _, layer_handle in entity_style_map.values():
        usage[layer_handle] = usage.get(layer_handle, 0) + 1
    if not usage:
        return {}

    resolved_layer_colors: dict[int, int] = {}
    for handle, (index, true_color) in layer_color_map.items():
        resolved_index, _ = _normalize_resolved_color(index, true_color)
        if resolved_index is not None:
            resolved_layer_colors[handle] = resolved_index

    gray_layers = [handle for handle, color in resolved_layer_colors.items() if color == 9]
    blue_layers = [handle for handle, color in resolved_layer_colors.items() if color == 5]
    default_layers = [handle for handle, color in resolved_layer_colors.items() if color == 7]
    if not gray_layers or not blue_layers or not default_layers:
        return {}

    dominant_gray = max(gray_layers, key=lambda handle: usage.get(handle, 0))
    missing_blue = min(blue_layers, key=lambda handle: usage.get(handle, 0))
    default_layer = min(default_layers)

    dominant_usage = usage.get(dominant_gray, 0)
    missing_blue_usage = usage.get(missing_blue, 0)
    default_usage = usage.get(default_layer, 0)
    total_usage = sum(usage.values())

    if total_usage < 40:
        return {}
    if dominant_usage < max(16, total_usage // 3):
        return {}
    if missing_blue_usage != 0:
        return {}
    if default_usage == 0:
        return {}

    return {
        dominant_gray: (5, None),
        default_layer: (9, None),
    }


def _attach_entity_color(
    handle: int,
    dxf: dict,
    entity_style_map: dict[int, tuple[int | None, int | None, int]],
    layer_color_map: dict[int, tuple[int, int | None]],
    layer_color_overrides: dict[int, tuple[int, int | None]] | None = None,
    dxftype: str | None = None,
) -> dict:
    index = dxf.get("color_index")
    true_color = dxf.get("true_color")
    layer_handle = dxf.get("layer_handle")
    resolved_index = dxf.get("resolved_color_index")
    resolved_true_color = dxf.get("resolved_true_color")

    style = entity_style_map.get(handle)
    if style is not None:
        index, true_color, layer_handle = style
        resolved_index = index
        resolved_true_color = true_color
    common_layer = getattr(entity_style_map, "common_layers", {}).get(handle)
    if common_layer is not None:
        layer_handle = common_layer
    # ENC stores the 0xC2 method byte along with RGB. The editable API uses
    # 24-bit colors, as do layer colors; leave the raw decode API unchanged.
    if isinstance(true_color, int) and true_color >> 24 == 0xC2:
        true_color &= 0xFFFFFF
    if isinstance(resolved_true_color, int) and resolved_true_color >> 24 == 0xC2:
        resolved_true_color &= 0xFFFFFF
    if index in (None, 0, 256, 257) and true_color is None and layer_handle is not None:
        layer_style = None
        if layer_color_overrides is not None:
            layer_style = layer_color_overrides.get(layer_handle)
        if layer_style is None:
            layer_style = layer_color_map.get(layer_handle)
        if layer_style is not None:
            resolved_index, resolved_true_color = layer_style

    if (
        layer_color_overrides is not None
        and dxftype == "ARC"
    ):
        source_layer = _override_source_layer(layer_color_overrides, 5)
        gray_layer = _override_source_layer(layer_color_overrides, 9)
        if (
            source_layer is not None
            and gray_layer is not None
            and layer_handle == gray_layer
            and source_layer in layer_color_overrides
        ):
            resolved_index, resolved_true_color = layer_color_overrides[source_layer]

    resolved_index, resolved_true_color = _normalize_resolved_color(
        resolved_index, resolved_true_color
    )

    dxf["color_index"] = index
    dxf["true_color"] = true_color
    dxf["layer_handle"] = layer_handle
    dxf["resolved_color_index"] = resolved_index
    dxf["resolved_true_color"] = resolved_true_color

    geometry = getattr(entity_style_map, "write_geometry", {}).get(handle)
    if geometry is not None:
        for key, value in zip(("thickness", "extrusion", "elevation"), geometry):
            if value is not None:
                dxf[key] = value
    mtext_properties = getattr(entity_style_map, "mtext_write_properties", {}).get(handle)
    if mtext_properties is not None:
        dxf["style_handle"], dxf["line_spacing_style"], dxf["line_spacing_factor"] = mtext_properties

    linetype = getattr(entity_style_map, "linetypes", {}).get(handle)
    if linetype is not None:
        dxf["linetype"], dxf["linetype_handle"], dxf["linetype_scale"] = linetype
    lineweight = getattr(entity_style_map, "lineweights", {}).get(handle)
    if lineweight is not None:
        dxf["lineweight"], dxf["invisible"] = lineweight
    return dxf


@lru_cache(maxsize=16)
def _geometry_layer_hint_rows(
    path: str,
) -> tuple[tuple[int, float, float, float, float, int], ...]:
    entity_style_map = _entity_style_map(path)
    out: list[tuple[int, float, float, float, float, int]] = []

    def _push(handle: int, min_x: float, max_x: float, min_y: float, max_y: float, weight: int) -> None:
        style = entity_style_map.get(int(handle))
        if style is None or style[2] is None:
            return
        layer_handle = int(style[2])
        if not all(math.isfinite(value) for value in (min_x, max_x, min_y, max_y)):
            return
        if not _is_reasonable_geometry_hint_extent(min_x, max_x, min_y, max_y):
            return
        out.append((layer_handle, min_x, max_x, min_y, max_y, weight))

    line_rows, arc_rows, circle_rows = _line_arc_circle_rows(path)
    for handle, sx, sy, _sz, ex, ey, _ez in line_rows:
        _push(int(handle), min(float(sx), float(ex)), max(float(sx), float(ex)), min(float(sy), float(ey)), max(float(sy), float(ey)), 4)
    for handle, cx, cy, _cz, radius, _start, _end in arc_rows:
        r = abs(float(radius))
        _push(int(handle), float(cx) - r, float(cx) + r, float(cy) - r, float(cy) + r, 2)
    for handle, cx, cy, _cz, radius in circle_rows:
        r = abs(float(radius))
        _push(int(handle), float(cx) - r, float(cx) + r, float(cy) - r, float(cy) + r, 2)
    try:
        for handle, _flags, points, _bulges, _widths, _const_width in raw.decode_lwpolyline_entities(path):
            xy = [(float(x), float(y)) for x, y in points]
            if not xy:
                continue
            xs = [point[0] for point in xy]
            ys = [point[1] for point in xy]
            _push(int(handle), min(xs), max(xs), min(ys), max(ys), 3)
    except Exception:
        pass
    return tuple(out)


def _is_reasonable_geometry_hint_extent(min_x: float, max_x: float, min_y: float, max_y: float) -> bool:
    values = (float(min_x), float(max_x), float(min_y), float(max_y))
    max_abs = max(abs(value) for value in values)
    if max_abs > 1.0e9:
        return False
    span_x = abs(float(max_x) - float(min_x))
    span_y = abs(float(max_y) - float(min_y))
    return span_x <= 1.0e8 and span_y <= 1.0e8


def _infer_nearby_layer_handle(
    path: str,
    insertion: tuple[float, float, float] | tuple[float, float],
) -> int | None:
    try:
        x = float(insertion[0])
        y = float(insertion[1])
    except Exception:
        return None

    scores: dict[int, int] = {}
    for layer_handle, min_x, max_x, min_y, max_y, weight in _geometry_layer_hint_rows(path):
        dx = 0.0
        if x < min_x:
            dx = min_x - x
        elif x > max_x:
            dx = x - max_x
        dy = 0.0
        if y < min_y:
            dy = min_y - y
        elif y > max_y:
            dy = y - max_y
        if dx > 1600.0 or dy > 900.0:
            continue
        score = int(weight)
        if dx <= 100.0:
            score += 6
        elif dx <= 400.0:
            score += 3
        elif dx <= 900.0:
            score += 1
        if dy <= 80.0:
            score += 6
        elif dy <= 250.0:
            score += 3
        elif dy <= 600.0:
            score += 1
        scores[layer_handle] = scores.get(layer_handle, 0) + score
    if not scores:
        return None
    return max(scores.items(), key=lambda item: (item[1], -item[0]))[0]


def _is_plausible_nearby_layer_handle(
    path: str,
    layer_handle: int | None,
    insertion: tuple[float, float, float] | tuple[float, float],
) -> bool:
    if layer_handle is None:
        return False
    try:
        wanted_layer_handle = int(layer_handle)
        x = float(insertion[0])
        y = float(insertion[1])
    except Exception:
        return False

    best_score = 0
    for row_layer_handle, min_x, max_x, min_y, max_y, weight in _geometry_layer_hint_rows(path):
        if row_layer_handle != wanted_layer_handle:
            continue
        dx = 0.0
        if x < min_x:
            dx = min_x - x
        elif x > max_x:
            dx = x - max_x
        dy = 0.0
        if y < min_y:
            dy = min_y - y
        elif y > max_y:
            dy = y - max_y
        if dx > 900.0 or dy > 450.0:
            continue
        score = int(weight)
        if dx <= 120.0:
            score += 8
        elif dx <= 360.0:
            score += 4
        if dy <= 80.0:
            score += 8
        elif dy <= 220.0:
            score += 4
        best_score = max(best_score, score)
    return best_score >= 12


def _line_supplementary_handles(
    line_rows: list[tuple[int, float, float, float, float, float, float]],
    entity_style_map: dict[int, tuple[int | None, int | None, int]],
    layer_color_overrides: dict[int, tuple[int, int | None]] | None,
) -> set[int]:
    if layer_color_overrides is None:
        return set()
    source_layer = _override_source_layer(layer_color_overrides, 5)
    if source_layer is None:
        return set()

    def _key(x: float, y: float, z: float) -> tuple[float, float, float]:
        return (round(x, 6), round(y, 6), round(z, 6))

    endpoint_usage: dict[tuple[float, float, float], int] = {}
    for handle, sx, sy, sz, ex, ey, ez in line_rows:
        style = entity_style_map.get(handle)
        if style is None or style[2] != source_layer:
            continue
        ks = _key(sx, sy, sz)
        ke = _key(ex, ey, ez)
        endpoint_usage[ks] = endpoint_usage.get(ks, 0) + 1
        endpoint_usage[ke] = endpoint_usage.get(ke, 0) + 1

    candidate_lengths: list[float] = []
    for handle, sx, sy, sz, ex, ey, ez in line_rows:
        style = entity_style_map.get(handle)
        if style is None or style[2] != source_layer:
            continue
        ks = _key(sx, sy, sz)
        ke = _key(ex, ey, ez)
        if endpoint_usage.get(ks, 0) != 1 or endpoint_usage.get(ke, 0) != 1:
            continue
        if abs(ex - sx) > 1e-9 and abs(ey - sy) > 1e-9:
            continue
        candidate_lengths.append(math.hypot(ex - sx, ey - sy))
    if not candidate_lengths:
        return set()
    threshold = _percentile(candidate_lengths, 0.75)

    result: set[int] = set()
    for handle, sx, sy, sz, ex, ey, ez in line_rows:
        style = entity_style_map.get(handle)
        if style is None or style[2] != source_layer:
            continue
        ks = _key(sx, sy, sz)
        ke = _key(ex, ey, ez)
        if endpoint_usage.get(ks, 0) != 1 or endpoint_usage.get(ke, 0) != 1:
            continue
        if abs(ex - sx) > 1e-9 and abs(ey - sy) > 1e-9:
            continue
        length = math.hypot(ex - sx, ey - sy)
        if length + 1e-9 >= threshold:
            result.add(handle)
    return result


def _circle_supplementary_handles(
    circle_rows: list[tuple[int, float, float, float, float]],
    entity_style_map: dict[int, tuple[int | None, int | None, int]],
    layer_color_overrides: dict[int, tuple[int, int | None]] | None,
) -> set[int]:
    if layer_color_overrides is None:
        return set()
    source_layer = _override_source_layer(layer_color_overrides, 5)
    if source_layer is None:
        return set()

    def _center_key(x: float, y: float, z: float) -> tuple[float, float, float]:
        return (round(x, 6), round(y, 6), round(z, 6))

    by_center: dict[tuple[float, float, float], list[tuple[int, float]]] = {}
    for handle, cx, cy, cz, radius in circle_rows:
        style = entity_style_map.get(handle)
        if style is None or style[2] != source_layer:
            continue
        key = _center_key(cx, cy, cz)
        by_center.setdefault(key, []).append((handle, radius))

    result: set[int] = set()
    for rows in by_center.values():
        if len(rows) < 2:
            continue
        sorted_rows = sorted(rows, key=lambda row: row[1], reverse=True)
        largest_handle, largest_radius = sorted_rows[0]
        second_radius = sorted_rows[1][1]
        if second_radius <= 0:
            continue
        ratio = largest_radius / second_radius
        if 2.0 <= ratio <= 4.0:
            result.add(largest_handle)
    return result


def _override_source_layer(
    layer_color_overrides: dict[int, tuple[int, int | None]],
    target_index: int,
) -> int | None:
    for handle, (index, _) in layer_color_overrides.items():
        if index == target_index:
            return handle
    return None


def _percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    sorted_values = sorted(values)
    if len(sorted_values) == 1:
        return sorted_values[0]
    pos = p * (len(sorted_values) - 1)
    lower = int(math.floor(pos))
    upper = int(math.ceil(pos))
    if lower == upper:
        return sorted_values[lower]
    weight = pos - lower
    return sorted_values[lower] * (1.0 - weight) + sorted_values[upper] * weight


def _normalize_resolved_color(
    index: int | None, true_color: int | None
) -> tuple[int | None, int | None]:
    if true_color is not None and 1 <= true_color <= 257:
        if index in (None, 0, 256, 257):
            return true_color, None
    return index, true_color
