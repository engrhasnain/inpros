from typing import Sequence

from .convert import ConvertResult, WriteDiagnostic, WriteResult, to_dwg, to_dxf
from ._write_preflight import (
    WRITE_CODEPAGES,
    is_representable,
    replace_unrepresentable,
    select_codepage,
)
from .document import Document, Layout, clear_decode_caches, read
from .drawing import BlockLayout, BlockTable, Drawing, EditableLayout, new
from .streaming import StreamingBlockLayout, StreamingDrawing, StreamingLayout, new_streaming
from .entity import Entity
from .layers import Layer, LayerTable, LayerPropertyNotImplemented
from .layer_states import (
    LayerState,
    LayerStateDiff,
    LayerStateDiffEntry,
    LayerStateEntry,
    LayerStateMasks,
    LayerStateTable,
    build_layer_state_table,
)
from .layer_filters import (
    LayerFilter,
    LayerFilterTable,
    LayerFilterTree,
    build_layer_filter_table,
    build_layer_filter_tree,
)
from . import lineweight
from .lineweight import lineweight_to_mm
from . import raw
from .graph import DocumentGraph, HeaderHandles, ObjectEdge, read_graph
from .render import plot

__all__ = [
    "WRITE_CODEPAGES",
    "select_codepage",
    "is_representable",
    "replace_unrepresentable",
    "read",
    "new",
    "new_streaming",
    "Drawing",
    "StreamingDrawing",
    "StreamingLayout",
    "StreamingBlockLayout",
    "BlockLayout",
    "BlockTable",
    "EditableLayout",
    "clear_decode_caches",
    "read_graph",
    "Document",
    "DocumentGraph",
    "HeaderHandles",
    "ObjectEdge",
    "Layout",
    "Entity",
    "Layer",
    "LayerTable",
    "LayerPropertyNotImplemented",
    "LayerState",
    "LayerStateDiff",
    "LayerStateDiffEntry",
    "LayerStateEntry",
    "LayerStateMasks",
    "LayerStateTable",
    "build_layer_state_table",
    "LayerFilter",
    "LayerFilterTable",
    "LayerFilterTree",
    "build_layer_filter_table",
    "build_layer_filter_tree",
    "lineweight",
    "lineweight_to_mm",
    "plot",
    "to_dxf",
    "to_dwg",
    "ConvertResult",
    "WriteResult",
    "WriteDiagnostic",
    "raw",
]


def main(argv: Sequence[str] | None = None) -> int:
    from ezdwg.cli import main as cli_main

    return cli_main(argv)
